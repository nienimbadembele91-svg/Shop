package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val code: String,
    val name: String,
    val brand: String,
    val category: String,
    val ram: String = "-",
    val storage: String = "-",
    val purchasePrice: Long,
    val sellingPrice: Long,
    val minPrice: Long,
    val stock: Int,
    val minStock: Int = 3,
    val supplier: String = "",
    val warrantyMonths: Int = 0,
    val isPhone: Boolean = false,
    val status: String = "disponible",
    val dateEntree: String = "",
    val etat: String? = null
)

@Entity(tableName = "product_imeis")
data class ProductImeiEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: String,
    val imei: String,
    val status: String = "en stock" // "en stock", "vendu"
)

@Entity(tableName = "sales")
data class SaleEntity(
    @PrimaryKey val id: String,
    val invoiceNo: String,
    val date: String,
    val dateTime: String,
    val seller: String,
    val customerId: String?,
    val customerName: String,
    val total: Long,
    val paid: Long,
    val remaining: Long,
    val paymentMethod: String
)

@Entity(tableName = "sale_items")
data class SaleItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: String,
    val productId: String,
    val name: String,
    val qty: Int,
    val imei: String? = null,
    val unitPrice: Long,
    val discount: Long = 0
)

@Entity(tableName = "stock_movements")
data class StockMovementEntity(
    @PrimaryKey val id: String,
    val date: String,
    val productId: String,
    val productName: String,
    val type: String, // "entrée", "vente", "correction", "sortie", "retour"
    val qty: Int,
    val oldStock: Int,
    val newStock: Int,
    val user: String,
    val reason: String
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val notes: String = "",
    val createdAt: String
)

@Entity(tableName = "suppliers")
data class SupplierEntity(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val notes: String = "",
    val createdAt: String
)

@Entity(tableName = "purchases")
data class PurchaseEntity(
    @PrimaryKey val id: String,
    val invoiceNo: String,
    val date: String,
    val supplierId: String,
    val supplierName: String,
    val total: Long,
    val paid: Long,
    val remaining: Long
)

@Entity(tableName = "purchase_items")
data class PurchaseItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val purchaseId: String,
    val productId: String,
    val name: String,
    val qty: Int,
    val unitCost: Long
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey val id: String,
    val date: String,
    val category: String,
    val description: String,
    val amount: Long,
    val paymentMethod: String,
    val user: String
)

@Entity(tableName = "app_users")
data class AppUserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val role: String,
    val pin: String,
    val active: Boolean = true
)

@Entity(tableName = "activity_logs")
data class ActivityLogEntity(
    @PrimaryKey val id: String,
    val date: String,
    val user: String,
    val action: String,
    val details: String
)
