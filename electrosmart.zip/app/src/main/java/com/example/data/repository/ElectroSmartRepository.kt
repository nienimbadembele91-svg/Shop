package com.example.data.repository

import com.example.data.dao.ElectroSmartDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.*

class ElectroSmartRepository(private val dao: ElectroSmartDao) {

    val products: Flow<List<ProductEntity>> = dao.getAllProducts()
    val imeis: Flow<List<ProductImeiEntity>> = dao.getAllImeis()
    val sales: Flow<List<SaleEntity>> = dao.getAllSales()
    val saleItems: Flow<List<SaleItemEntity>> = dao.getAllSaleItems()
    val movements: Flow<List<StockMovementEntity>> = dao.getAllMovements()
    val customers: Flow<List<CustomerEntity>> = dao.getAllCustomers()
    val suppliers: Flow<List<SupplierEntity>> = dao.getAllSuppliers()
    val purchases: Flow<List<PurchaseEntity>> = dao.getAllPurchases()
    val expenses: Flow<List<ExpenseEntity>> = dao.getAllExpenses()
    val users: Flow<List<AppUserEntity>> = dao.getAllUsers()
    val activityLogs: Flow<List<ActivityLogEntity>> = dao.getAllActivityLogs()

    private fun todayIso(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    private fun nowIso(): String {
        return SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(Date())
    }

    private fun daysAgoIso(days: Int): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -days)
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
    }

    suspend fun seedDatabaseIfEmpty() {
        val existingUsers = dao.getAllUsers().first()
        if (existingUsers.isNotEmpty()) return

        // 1. Seed Users
        val seedUsers = listOf(
            AppUserEntity("u1", "Aïssata Diarra", "Administrateur", "1111", true),
            AppUserEntity("u2", "Moussa Koné", "Gérant", "2222", true),
            AppUserEntity("u3", "Fatoumata Sy", "Caissier", "3333", true),
            AppUserEntity("u4", "Sékou Bamba", "Magasinier", "4444", true)
        )
        dao.insertUsers(seedUsers)

        // 2. Seed Suppliers
        val seedSuppliers = listOf(
            SupplierEntity("sup1", "Bamako Mobile Distrib", "+223 20 00 00 01", "Zone industrielle, Bamako", "", daysAgoIso(60)),
            SupplierEntity("sup2", "Import Dakar SARL", "+221 33 00 00 02", "Dakar, Sénégal", "", daysAgoIso(45)),
            SupplierEntity("sup3", "Global Phones Import", "+223 70 00 00 03", "Grand Marché, Bamako", "", daysAgoIso(30))
        )
        dao.insertSuppliers(seedSuppliers)

        // 3. Seed Customers
        val seedCustomers = listOf(
            CustomerEntity("c1", "Aminata Coulibaly", "+223 76 00 00 01", "Hamdallaye, Bamako", "Cliente fidèle", daysAgoIso(30)),
            CustomerEntity("c2", "Ibrahima Cissé", "+223 65 00 00 02", "Kalaban Coura", "", daysAgoIso(15)),
            CustomerEntity("c3", "Mariam Diallo", "+223 78 00 00 03", "ACI 2000, Bamako", "Préfère Orange Money", daysAgoIso(10))
        )
        dao.insertCustomers(seedCustomers)

        // 4. Seed Products
        val rawProducts = listOf(
            ProductEntity("p1", "SKU0001", "Camon 20", "TECNO", "Téléphone", "8Go", "256Go", 95000, 125000, 115000, 6, 3, "Import Dakar SARL", 12, true, "disponible", todayIso(), "neuf"),
            ProductEntity("p2", "SKU0002", "Hot 40", "Infinix", "Téléphone", "6Go", "128Go", 62000, 85000, 78000, 2, 3, "Bamako Mobile Distrib", 12, true, "disponible", todayIso(), "neuf"),
            ProductEntity("p3", "SKU0003", "A70", "itel", "Téléphone", "4Go", "64Go", 28000, 42000, 38000, 9, 4, "Bamako Mobile Distrib", 6, true, "disponible", todayIso(), "neuf"),
            ProductEntity("p4", "SKU0004", "Galaxy A15", "Samsung", "Téléphone", "4Go", "128Go", 78000, 105000, 98000, 4, 2, "Import Dakar SARL", 12, true, "disponible", todayIso(), "neuf"),
            ProductEntity("p5", "SKU0005", "Redmi 13C", "Xiaomi", "Téléphone", "6Go", "128Go", 58000, 79000, 72000, 0, 3, "Import Dakar SARL", 12, true, "rupture", todayIso(), "neuf"),
            ProductEntity("p6", "SKU0006", "iPhone 11 (reconditionné)", "Apple", "Téléphone", "4Go", "64Go", 145000, 195000, 180000, 3, 1, "Global Phones Import", 3, true, "disponible", todayIso(), "reconditionné"),
            ProductEntity("p7", "SKU0007", "Chargeur rapide 33W", "Xiaomi", "Accessoire", "-", "-", 4500, 8000, 7000, 22, 8, "Bamako Mobile Distrib", 3, false, "disponible", todayIso(), null),
            ProductEntity("p8", "SKU0008", "Écouteurs Bluetooth TWS", "itel", "Accessoire", "-", "-", 6000, 12000, 10000, 5, 6, "Bamako Mobile Distrib", 3, false, "disponible", todayIso(), null),
            ProductEntity("p9", "SKU0009", "Coque silicone universelle", "TECNO", "Accessoire", "-", "-", 1000, 3000, 2500, 40, 10, "Marché local", 0, false, "disponible", todayIso(), null)
        )
        dao.insertProducts(rawProducts)

        // Seed IMEIs for phones
        val imeisToInsert = mutableListOf<ProductImeiEntity>()
        rawProducts.forEachIndexed { pIndex, p ->
            if (p.isPhone && p.stock > 0) {
                for (k in 0 until p.stock) {
                    val imeiNum = "35" + (100000000000L + pIndex * 1000 + k).toString().take(13)
                    imeisToInsert.add(ProductImeiEntity(productId = p.id, imei = imeiNum, status = "en stock"))
                }
            }
        }
        dao.insertImeis(imeisToInsert)

        // 5. Seed Initial Stock Movements
        val movementsToInsert = rawProducts.map { p ->
            StockMovementEntity(
                id = "m_init_${p.id}",
                date = nowIso(),
                productId = p.id,
                productName = "${p.brand} ${p.name}",
                type = "entrée",
                qty = p.stock,
                oldStock = 0,
                newStock = p.stock,
                user = "Système",
                reason = "Stock initial boutique"
            )
        }
        movementsToInsert.forEach { dao.insertMovement(it) }

        // 6. Seed Past Sales for realistic charts
        val sale1 = SaleEntity(
            id = "seed1",
            invoiceNo = "F1001",
            date = daysAgoIso(2),
            dateTime = daysAgoIso(2) + "T10:30:00",
            seller = "Fatoumata Sy",
            customerId = null,
            customerName = "Client comptoir",
            total = 84000,
            paid = 84000,
            remaining = 0,
            paymentMethod = "Espèces"
        )
        dao.insertSale(sale1)
        dao.insertSaleItems(listOf(
            SaleItemEntity(saleId = "seed1", productId = "p3", name = "itel A70", qty = 2, imei = "3510000000200", unitPrice = 42000, discount = 0)
        ))

        val sale2 = SaleEntity(
            id = "seed2",
            invoiceNo = "F1002",
            date = daysAgoIso(1),
            dateTime = daysAgoIso(1) + "T14:15:00",
            seller = "Moussa Koné",
            customerId = "c1",
            customerName = "Aminata Coulibaly",
            total = 103000,
            paid = 60000,
            remaining = 43000,
            paymentMethod = "Crédit"
        )
        dao.insertSale(sale2)
        dao.insertSaleItems(listOf(
            SaleItemEntity(saleId = "seed2", productId = "p4", name = "Samsung Galaxy A15", qty = 1, imei = "3510000000300", unitPrice = 105000, discount = 2000)
        ))

        val sale3 = SaleEntity(
            id = "seed3",
            invoiceNo = "F1003",
            date = todayIso(),
            dateTime = nowIso(),
            seller = "Fatoumata Sy",
            customerId = "c3",
            customerName = "Mariam Diallo",
            total = 20000,
            paid = 20000,
            remaining = 0,
            paymentMethod = "Orange Money"
        )
        dao.insertSale(sale3)
        dao.insertSaleItems(listOf(
            SaleItemEntity(saleId = "seed3", productId = "p7", name = "Xiaomi Chargeur rapide 33W", qty = 1, imei = null, unitPrice = 8000, discount = 0),
            SaleItemEntity(saleId = "seed3", productId = "p8", name = "itel Écouteurs Bluetooth TWS", qty = 1, imei = null, unitPrice = 12000, discount = 0)
        ))

        // 7. Seed Initial Expenses
        dao.insertExpense(ExpenseEntity("e1", todayIso(), "Électricité", "Facture EDM du mois", 15000, "Orange Money", "Aïssata Diarra"))
        dao.insertExpense(ExpenseEntity("e2", daysAgoIso(3), "Internet", "Abonnement fibre Orange Mali", 25000, "Orange Money", "Moussa Koné"))

        // 8. Seed Initial Activity Log
        dao.insertActivityLog(ActivityLogEntity("a1", nowIso(), "Système", "Initialisation", "Boutique configurée avec succès"))
    }

    suspend fun insertProduct(product: ProductEntity, initialImeis: List<String> = emptyList()) {
        dao.insertProduct(product)
        if (product.isPhone && initialImeis.isNotEmpty()) {
            val imeis = initialImeis.map {
                ProductImeiEntity(productId = product.id, imei = it, status = "en stock")
            }
            dao.insertImeis(imeis)
        }
    }

    suspend fun updateProduct(product: ProductEntity) {
        dao.updateProduct(product)
    }

    suspend fun adjustStock(productId: String, qtyChange: Int, reason: String, userName: String) {
        val product = dao.getProductById(productId) ?: return
        val oldStock = product.stock
        val newStock = (oldStock + qtyChange).coerceAtLeast(0)
        val newStatus = if (newStock == 0) "rupture" else "disponible"
        dao.updateProduct(product.copy(stock = newStock, status = newStatus))

        dao.insertMovement(
            StockMovementEntity(
                id = "m_${System.currentTimeMillis()}",
                date = nowIso(),
                productId = productId,
                productName = "${product.brand} ${product.name}",
                type = if (qtyChange > 0) "entrée" else "correction",
                qty = kotlin.math.abs(qtyChange),
                oldStock = oldStock,
                newStock = newStock,
                user = userName,
                reason = reason
            )
        )
    }

    suspend fun recordSale(
        sale: SaleEntity,
        items: List<SaleItemEntity>,
        soldImeis: List<String>
    ) {
        dao.insertSale(sale)
        dao.insertSaleItems(items)

        // update IMEI status
        soldImeis.forEach { imei ->
            dao.updateImeiStatus(imei, "vendu")
        }

        // update product stocks and log movements
        items.forEach { item ->
            val product = dao.getProductById(item.productId)
            if (product != null) {
                val oldStock = product.stock
                val newStock = (oldStock - item.qty).coerceAtLeast(0)
                val newStatus = if (newStock == 0) "rupture" else "disponible"
                dao.updateProduct(product.copy(stock = newStock, status = newStatus))

                dao.insertMovement(
                    StockMovementEntity(
                        id = "m_sale_${System.currentTimeMillis()}_${item.productId}",
                        date = nowIso(),
                        productId = product.id,
                        productName = item.name,
                        type = "vente",
                        qty = item.qty,
                        oldStock = oldStock,
                        newStock = newStock,
                        user = sale.seller,
                        reason = "Vente facture ${sale.invoiceNo}"
                    )
                )
            }
        }

        dao.insertActivityLog(
            ActivityLogEntity(
                id = "a_${System.currentTimeMillis()}",
                date = nowIso(),
                user = sale.seller,
                action = "Nouvelle vente",
                details = "${sale.invoiceNo} · ${sale.customerName} · Total: ${sale.total} F"
            )
        )
    }

    suspend fun recordCreditPayment(saleId: String, amount: Long, method: String, userName: String) {
        val allSales = dao.getAllSales().first()
        val sale = allSales.find { it.id == saleId } ?: return
        val applied = amount.coerceAtMost(sale.remaining)
        val newPaid = sale.paid + applied
        val newRemaining = (sale.remaining - applied).coerceAtLeast(0)
        val updatedSale = sale.copy(paid = newPaid, remaining = newRemaining)
        dao.updateSale(updatedSale)

        dao.insertActivityLog(
            ActivityLogEntity(
                id = "a_${System.currentTimeMillis()}",
                date = nowIso(),
                user = userName,
                action = "Paiement créance",
                details = "Facture ${sale.invoiceNo} · Payé: $applied F via $method"
            )
        )
    }

    suspend fun insertCustomer(customer: CustomerEntity) {
        dao.insertCustomer(customer)
    }

    suspend fun updateCustomer(customer: CustomerEntity) {
        dao.updateCustomer(customer)
    }

    suspend fun insertSupplier(supplier: SupplierEntity) {
        dao.insertSupplier(supplier)
    }

    suspend fun updateSupplier(supplier: SupplierEntity) {
        dao.updateSupplier(supplier)
    }

    suspend fun recordPurchase(
        purchase: PurchaseEntity,
        items: List<PurchaseItemEntity>,
        userName: String
    ) {
        dao.insertPurchase(purchase)
        dao.insertPurchaseItems(items)

        // update stock for each item
        items.forEach { line ->
            val product = dao.getProductById(line.productId)
            if (product != null) {
                val oldStock = product.stock
                val newStock = oldStock + line.qty
                dao.updateProduct(product.copy(stock = newStock, status = "disponible"))

                if (product.isPhone) {
                    val newImeis = (0 until line.qty).map { k ->
                        ProductImeiEntity(
                            productId = product.id,
                            imei = "35" + (System.currentTimeMillis() % 100000000000L + k),
                            status = "en stock"
                        )
                    }
                    dao.insertImeis(newImeis)
                }

                dao.insertMovement(
                    StockMovementEntity(
                        id = "m_pur_${System.currentTimeMillis()}_${line.productId}",
                        date = nowIso(),
                        productId = product.id,
                        productName = "${product.brand} ${product.name}",
                        type = "entrée",
                        qty = line.qty,
                        oldStock = oldStock,
                        newStock = newStock,
                        user = userName,
                        reason = "Achat fournisseur ${purchase.invoiceNo}"
                    )
                )
            }
        }

        dao.insertActivityLog(
            ActivityLogEntity(
                id = "a_${System.currentTimeMillis()}",
                date = nowIso(),
                user = userName,
                action = "Achat fournisseur",
                details = "${purchase.invoiceNo} · ${purchase.supplierName} · Total: ${purchase.total} F"
            )
        )
    }

    suspend fun insertExpense(expense: ExpenseEntity) {
        dao.insertExpense(expense)
        dao.insertActivityLog(
            ActivityLogEntity(
                id = "a_${System.currentTimeMillis()}",
                date = nowIso(),
                user = expense.user,
                action = "Ajout dépense",
                details = "${expense.category} · ${expense.amount} F"
            )
        )
    }

    suspend fun deleteExpense(id: String) {
        dao.deleteExpense(id)
    }

    suspend fun insertUser(user: AppUserEntity) {
        dao.insertUser(user)
    }

    suspend fun updateUser(user: AppUserEntity) {
        dao.updateUser(user)
    }

    suspend fun logActivity(user: String, action: String, details: String) {
        dao.insertActivityLog(
            ActivityLogEntity(
                id = "a_${System.currentTimeMillis()}",
                date = nowIso(),
                user = user,
                action = action,
                details = details
            )
        )
    }

    suspend fun wipeAllData() {
        dao.clearProducts()
        dao.clearImeis()
        dao.clearSales()
        dao.clearSaleItems()
        dao.clearMovements()
        dao.clearCustomers()
        dao.clearSuppliers()
        dao.clearPurchases()
        dao.clearPurchaseItems()
        dao.clearExpenses()
        dao.clearActivityLogs()
    }
}
