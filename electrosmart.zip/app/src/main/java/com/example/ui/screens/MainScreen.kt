package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ElectroBottomNav
import com.example.ui.components.Pill
import com.example.ui.components.PillTone
import com.example.ui.theme.*
import com.example.ui.viewmodel.ElectroSmartViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: ElectroSmartViewModel
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val users by viewModel.users.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val imeis by viewModel.imeis.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val saleItems by viewModel.saleItems.collectAsStateWithLifecycle()
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()
    val purchases by viewModel.purchases.collectAsStateWithLifecycle()
    val expenses by viewModel.expenses.collectAsStateWithLifecycle()
    val movements by viewModel.movements.collectAsStateWithLifecycle()
    val activityLogs by viewModel.activityLogs.collectAsStateWithLifecycle()

    val permissions by viewModel.currentPermissions.collectAsStateWithLifecycle()

    // Navigation state
    var activeTab by remember { mutableStateOf("dashboard") }
    var activeSubModule by remember { mutableStateOf<String?>(null) }

    // If activeTab is not allowed for user role, fallback to first allowed tab
    LaunchedEffect(currentUser, permissions.tabs) {
        if (!permissions.tabs.contains(activeTab) && permissions.tabs.isNotEmpty()) {
            activeTab = permissions.tabs.first()
        }
    }

    if (currentUser == null) {
        LoginScreen(
            users = users,
            onLogin = { user -> viewModel.login(user) }
        )
        return
    }

    val lowStockCount = products.count { it.stock <= it.minStock }

    BackHandler(enabled = activeSubModule != null) {
        activeSubModule = null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (activeSubModule != null) {
                        val title = when (activeSubModule) {
                            "suppliers" -> "Fournisseurs & Achats"
                            "expenses" -> "Dépenses"
                            "reports" -> "Rapports"
                            "audit" -> "Journal d'activité"
                            else -> "Gestion"
                        }
                        Text(
                            text = title,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "ELECTRO_SMART",
                                fontSize = 16.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                letterSpacing = 0.5.sp
                            )
                            Pill(
                                text = currentUser?.role ?: "",
                                tone = PillTone.MUTED
                            )
                        }
                    }
                },
                navigationIcon = {
                    if (activeSubModule != null) {
                        IconButton(
                            onClick = { activeSubModule = null },
                            modifier = Modifier.testTag("submodule_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Retour",
                                tint = Color.White
                            )
                        }
                    }
                },
                actions = {
                    if (lowStockCount > 0 && activeSubModule == null) {
                        IconButton(
                            onClick = {
                                if (permissions.tabs.contains("stock")) {
                                    activeTab = "stock"
                                }
                            },
                            modifier = Modifier.testTag("top_bar_alert_icon")
                        ) {
                            Badge(containerColor = GoldDark) {
                                Text("$lowStockCount", color = Color.White, fontSize = 10.sp)
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = InkPrimary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            if (activeSubModule == null) {
                ElectroBottomNav(
                    activeTab = activeTab,
                    onTabSelected = { activeTab = it },
                    allowedTabs = permissions.tabs
                )
            }
        },
        containerColor = PaperBackground
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (activeSubModule != null) {
                when (activeSubModule) {
                    "suppliers" -> SuppliersScreen(
                        suppliers = suppliers,
                        purchases = purchases,
                        products = products,
                        permissions = permissions,
                        onAddSupplier = { name, phone, addr, notes -> viewModel.addSupplier(name, phone, addr, notes) },
                        onUpdateSupplier = { s -> viewModel.updateSupplier(s) },
                        onRecordPurchase = { supId, supName, items, paid -> viewModel.recordPurchase(supId, supName, items, paid) }
                    )
                    "expenses" -> ExpensesScreen(
                        expenses = expenses,
                        permissions = permissions,
                        onAddExpense = { cat, desc, amt, meth -> viewModel.addExpense(cat, desc, amt, meth) },
                        onDeleteExpense = { id -> viewModel.deleteExpense(id) }
                    )
                    "reports" -> ReportsScreen(
                        sales = sales,
                        saleItems = saleItems,
                        products = products,
                        expenses = expenses,
                        purchases = purchases,
                        customers = customers,
                        suppliers = suppliers
                    )
                    "audit" -> AuditScreen(
                        auditLogs = activityLogs
                    )
                }
            } else {
                when (activeTab) {
                    "dashboard" -> DashboardScreen(
                        products = products,
                        sales = sales,
                        saleItems = saleItems,
                        expenses = expenses,
                        purchases = purchases,
                        onNavigateToSales = { activeTab = "sales" },
                        onNavigateToStock = { activeTab = "stock" }
                    )
                    "sales" -> SalesScreen(
                        products = products,
                        imeis = imeis,
                        sales = sales,
                        saleItems = saleItems,
                        customers = customers,
                        onCheckout = { custName, custId, items, meth, paid ->
                            viewModel.checkoutSale(custName, custId, items, meth, paid)
                        },
                        onQuickAddCustomer = { name -> viewModel.addCustomer(name, "", "", "") }
                    )
                    "stock" -> StockScreen(
                        products = products,
                        movements = movements,
                        permissions = permissions,
                        onValidateInventory = { counts -> viewModel.recordPhysicalInventory(counts) }
                    )
                    "products" -> ProductsScreen(
                        products = products,
                        imeis = imeis,
                        permissions = permissions,
                        onAddProduct = { name, brand, cat, ram, storage, pPrice, sPrice, mPrice, stock, minStock, supp, war ->
                            viewModel.addProduct(name, brand, cat, ram, storage, pPrice, sPrice, mPrice, stock, minStock, supp, war)
                        },
                        onAdjustStock = { prodId, qty, reason ->
                            viewModel.adjustStock(prodId, qty, reason)
                        }
                    )
                    "clients" -> ClientsScreen(
                        customers = customers,
                        sales = sales,
                        permissions = permissions,
                        onAddCustomer = { name, phone, addr, notes -> viewModel.addCustomer(name, phone, addr, notes) },
                        onUpdateCustomer = { c -> viewModel.updateCustomer(c) },
                        onRecordPayment = { saleId, amt, meth -> viewModel.recordCreditPayment(saleId, amt, meth) }
                    )
                    "more" -> MoreScreen(
                        currentUser = currentUser!!,
                        users = users,
                        permissions = permissions,
                        onLogout = { viewModel.logout() },
                        onOpenModule = { module -> activeSubModule = module },
                        onAddUser = { name, role, pin -> viewModel.addUser(name, role, pin) },
                        onUpdateUser = { u -> viewModel.updateUser(u) },
                        onToggleUserActive = { u -> viewModel.toggleUserActive(u) },
                        onWipeAllData = { viewModel.wipeAllData() }
                    )
                }
            }
        }
    }
}
