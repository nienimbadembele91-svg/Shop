package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = TealAccent,
    secondary = GoldAccent,
    tertiary = AmberAccent,
    background = InkPrimary,
    surface = InkSecondary,
    onPrimary = Color.White,
    onSecondary = InkPrimary,
    onBackground = Color.White,
    onSurface = Color.White,
)

private val LightColorScheme = lightColorScheme(
    primary = TealAccent,
    secondary = GoldAccent,
    tertiary = AmberAccent,
    background = PaperBackground,
    surface = CardBackground,
    onPrimary = Color.White,
    onSecondary = InkPrimary,
    onBackground = TextColor,
    onSurface = TextColor,
    surfaceVariant = Color(0xFFF2EFE7),
    outline = BorderColor,
)

@Composable
fun ElectroSmartTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

