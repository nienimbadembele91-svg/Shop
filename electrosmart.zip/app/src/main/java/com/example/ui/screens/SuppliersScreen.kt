package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProductEntity
import com.example.data.model.PurchaseEntity
import com.example.data.model.SupplierEntity
import com.example.ui.components.*
import com.example.ui.model.RolePermissions
import com.example.ui.theme.*
import com.example.ui.viewmodel.PurchaseCartItem

@Composable
fun SuppliersScreen(
    suppliers: List<SupplierEntity>,
    purchases: List<PurchaseEntity>,
    products: List<ProductEntity>,
    permissions: RolePermissions,
    onAddSupplier: (name: String, phone: String, address: String, notes: String) -> Unit,
    onUpdateSupplier: (supplier: SupplierEntity) -> Unit,
    onRecordPurchase: (supplierId: String, supplierName: String, items: List<PurchaseCartItem>, paidAmount: Long) -> Unit
) {
    var selectedTab by remember { mutableStateOf("suppliers") } // "suppliers" | "purchases"
    var showSupplierDialog by remember { mutableStateOf(false) }
    var editingSupplier by remember { mutableStateOf<SupplierEntity?>(null) }
    var selectedSupplierDetail by remember { mutableStateOf<SupplierEntity?>(null) }
    var showPurchaseDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperBackground)
    ) {
        // Tab selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("suppliers" to "Fournisseurs", "purchases" to "Achats").forEach { (key, label) ->
                val isSelected = selectedTab == key
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) InkPrimary else CardBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { selectedTab = key }
                        .testTag("supplier_tab_$key")
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) Color.White else TextMuted,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(vertical = 9.dp)
                    )
                }
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            if (selectedTab == "suppliers") {
                if (suppliers.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("Aucun fournisseur enregistré.", fontSize = 13.sp, color = TextMuted)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(suppliers, key = { it.id }) { s ->
                            val supplierPurchases = purchases.filter { it.supplierId == s.id }
                            val totalPurchased = supplierPurchases.sumOf { it.total }
                            val debt = supplierPurchases.sumOf { it.remaining }

                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = CardBackground,
                                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedSupplierDetail = s }
                                    .testTag("supplier_item_${s.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(s.name, fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = TextColor)
                                        Text(
                                            text = "${s.phone.ifEmpty { "—" }} · Acheté : ${formatCurrency(totalPurchased)}",
                                            fontSize = 11.5.sp,
                                            color = TextMuted
                                        )
                                    }
                                    if (debt > 0) {
                                        Pill("Dette ${formatCurrency(debt)}", tone = PillTone.AMBER)
                                    } else {
                                        Pill("À jour", tone = PillTone.TEAL)
                                    }
                                }
                            }
                        }
                    }
                }

                if (permissions.canManageSuppliers) {
                    FloatingActionButton(
                        onClick = {
                            editingSupplier = null
                            showSupplierDialog = true
                        },
                        containerColor = TealAccent,
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 20.dp, bottom = 20.dp)
                            .testTag("add_supplier_fab")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Ajouter un fournisseur")
                    }
                }
            } else {
                // Purchases
                if (purchases.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("Aucun achat enregistré.", fontSize = 13.sp, color = TextMuted)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(purchases, key = { it.id }) { p ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = CardBackground,
                                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("${p.invoiceNo} · ${p.supplierName}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextColor)
                                        Pill(
                                            text = if (p.remaining > 0) "Dette" else "Payé",
                                            tone = if (p.remaining > 0) PillTone.AMBER else PillTone.TEAL
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(p.date, fontSize = 11.sp, color = TextMuted)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(formatCurrency(p.total), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                                }
                            }
                        }
                    }
                }

                if (permissions.canManageSuppliers) {
                    FloatingActionButton(
                        onClick = { showPurchaseDialog = true },
                        containerColor = TealAccent,
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 20.dp, bottom = 20.dp)
                            .testTag("add_purchase_fab")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Nouvel achat")
                    }
                }
            }
        }
    }

    // Detail Sheet
    if (selectedSupplierDetail != null) {
        val s = selectedSupplierDetail!!
        val supplierPurchases = purchases.filter { it.supplierId == s.id }
        val totalPurchased = supplierPurchases.sumOf { it.total }
        val debt = supplierPurchases.sumOf { it.remaining }

        BottomSheetContainer(
            title = s.name,
            onClose = { selectedSupplierDetail = null }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                    if (debt > 0) Pill("Dette : ${formatCurrency(debt)}", tone = PillTone.AMBER)
                    else Pill("Aucune dette", tone = PillTone.TEAL)
                    Pill("${supplierPurchases.size} achat(s)", tone = PillTone.MUTED)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(shape = RoundedCornerShape(10.dp), color = PaperBackground, modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Téléphone", fontSize = 10.5.sp, color = TextMuted)
                            Text(s.phone.ifEmpty { "—" }, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Surface(shape = RoundedCornerShape(10.dp), color = PaperBackground, modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Total acheté", fontSize = 10.5.sp, color = TextMuted)
                            Text(formatCurrency(totalPurchased), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text("Historique des achats", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = InkPrimary, modifier = Modifier.padding(bottom = 8.dp))

                if (supplierPurchases.isEmpty()) {
                    Text("Aucun achat enregistré.", fontSize = 12.sp, color = TextMuted)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        supplierPurchases.reversed().forEach { p ->
                            Surface(shape = RoundedCornerShape(10.dp), color = PaperBackground, modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("${p.invoiceNo} · ${p.date}", fontSize = 12.sp)
                                    Text(formatCurrency(p.total), fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                if (permissions.canManageSuppliers) {
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedButton(
                        onClick = {
                            editingSupplier = s
                            selectedSupplierDetail = null
                            showSupplierDialog = true
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(46.dp)
                    ) {
                        Text("Modifier ce fournisseur", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Add / Edit Supplier
    if (showSupplierDialog) {
        SupplierFormDialog(
            initial = editingSupplier,
            onClose = {
                showSupplierDialog = false
                editingSupplier = null
            },
            onSave = { name, phone, address, notes ->
                if (editingSupplier != null) {
                    onUpdateSupplier(editingSupplier!!.copy(name = name, phone = phone, address = address, notes = notes))
                } else {
                    onAddSupplier(name, phone, address, notes)
                }
                showSupplierDialog = false
                editingSupplier = null
            }
        )
    }

    // New Purchase Sheet
    if (showPurchaseDialog) {
        NewPurchaseDialog(
            suppliers = suppliers,
            products = products,
            onClose = { showPurchaseDialog = false },
            onSave = { supId, supName, items, paid ->
                onRecordPurchase(supId, supName, items, paid)
                showPurchaseDialog = false
            }
        )
    }
}

@Composable
fun SupplierFormDialog(
    initial: SupplierEntity?,
    onClose: () -> Unit,
    onSave: (name: String, phone: String, address: String, notes: String) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var address by remember { mutableStateOf(initial?.address ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }

    val isValid = name.isNotBlank()

    BottomSheetContainer(
        title = if (initial != null) "Modifier le fournisseur" else "Nouveau fournisseur",
        onClose = onClose,
        footer = {
            Button(
                onClick = { if (isValid) onSave(name, phone, address, notes) },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_supplier_button")
            ) {
                Text(if (initial != null) "Enregistrer" else "Ajouter le fournisseur", fontWeight = FontWeight.Bold)
            }
        }
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            FormField(label = "Nom du fournisseur *") {
                StyledTextInput(value = name, onValueChange = { name = it }, placeholder = "ex : Bamako Mobile Distrib")
            }
            FormField(label = "Téléphone") {
                StyledTextInput(value = phone, onValueChange = { phone = it }, placeholder = "+223 XX XX XX XX")
            }
            FormField(label = "Adresse") {
                StyledTextInput(value = address, onValueChange = { address = it }, placeholder = "Zone industrielle, Bamako")
            }
            FormField(label = "Notes") {
                StyledTextInput(value = notes, onValueChange = { notes = it }, placeholder = "Conditions, délais...")
            }
        }
    }
}

@Composable
fun NewPurchaseDialog(
    suppliers: List<SupplierEntity>,
    products: List<ProductEntity>,
    onClose: () -> Unit,
    onSave: (supplierId: String, supplierName: String, items: List<PurchaseCartItem>, paidAmount: Long) -> Unit
) {
    var selectedSupplierId by remember { mutableStateOf(suppliers.firstOrNull()?.id ?: "") }
    var newSupplierName by remember { mutableStateOf("") }
    var productSearch by remember { mutableStateOf("") }
    val purchaseItems = remember { mutableStateListOf<PurchaseCartItem>() }
    var paidAmountStr by remember { mutableStateOf("") }

    val matchedProducts = remember(products, productSearch) {
        val q = productSearch.trim().lowercase()
        if (q.isEmpty()) emptyList()
        else products.filter { "${it.brand} ${it.name}".lowercase().contains(q) }
    }

    val totalCost = purchaseItems.sumOf { it.qty * it.unitCost }
    val paid = if (paidAmountStr.isBlank()) totalCost else (paidAmountStr.toLongOrNull() ?: totalCost)
    val remaining = (totalCost - paid).coerceAtLeast(0)

    val isValid = (selectedSupplierId.isNotEmpty() || newSupplierName.isNotBlank()) && purchaseItems.isNotEmpty()

    BottomSheetContainer(
        title = "Nouvel achat fournisseur",
        onClose = onClose,
        footer = {
            Button(
                onClick = {
                    if (isValid) {
                        val supName = suppliers.find { it.id == selectedSupplierId }?.name ?: newSupplierName
                        val supId = selectedSupplierId.ifEmpty { "sup_new_${System.currentTimeMillis()}" }
                        onSave(supId, supName, purchaseItems.toList(), paid)
                    }
                },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("confirm_purchase_button")
            ) {
                Text("Enregistrer l'achat (${formatCurrency(totalCost)})", fontWeight = FontWeight.Bold)
            }
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            FormField(label = "Fournisseur") {
                if (suppliers.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        suppliers.take(3).forEach { s ->
                            val isSelected = selectedSupplierId == s.id
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) InkPrimary else PaperBackground,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                                modifier = Modifier.clickable { selectedSupplierId = s.id }
                            ) {
                                Text(
                                    text = s.name,
                                    fontSize = 11.5.sp,
                                    color = if (isSelected) Color.White else TextColor,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                } else {
                    StyledTextInput(value = newSupplierName, onValueChange = { newSupplierName = it }, placeholder = "Nom du fournisseur")
                }
            }

            FormField(label = "Ajouter un produit du catalogue") {
                ElectroSearchField(
                    query = productSearch,
                    onQueryChange = { productSearch = it },
                    placeholder = "Rechercher un produit..."
                )

                if (matchedProducts.isNotEmpty()) {
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = CardBackground),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            matchedProducts.forEach { p ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            val existing = purchaseItems.indexOfFirst { it.productId == p.id }
                                            if (existing >= 0) {
                                                val itm = purchaseItems[existing]
                                                purchaseItems[existing] = itm.copy(qty = itm.qty + 1)
                                            } else {
                                                purchaseItems.add(
                                                    PurchaseCartItem(
                                                        productId = p.id,
                                                        name = "${p.brand} ${p.name}",
                                                        qty = 1,
                                                        unitCost = p.purchasePrice
                                                    )
                                                )
                                            }
                                            productSearch = ""
                                        }
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${p.brand} ${p.name}", fontSize = 12.sp)
                                    Icon(Icons.Default.Add, contentDescription = null, tint = TealAccent, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }

            // Items list
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                purchaseItems.forEachIndexed { idx, itm ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = CardBackground,
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(itm.name, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("Qté: ${itm.qty}", fontSize = 11.sp, color = TextMuted)
                                    Text("Coût: ${formatCurrency(itm.unitCost)}", fontSize = 11.sp, color = TextMuted)
                                }
                            }
                            IconButton(onClick = { purchaseItems.removeAt(idx) }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Supprimer", modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }

            FormField(label = "Montant payé (Total : ${formatCurrency(totalCost)})") {
                StyledTextInput(
                    value = paidAmountStr,
                    onValueChange = { paidAmountStr = it },
                    placeholder = "$totalCost",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }

            if (remaining > 0) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AmberSoft,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                ) {
                    Text(
                        text = "Dette fournisseur enregistrée : ${formatCurrency(remaining)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = GoldDark,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}
