package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.*
import com.example.data.repository.ElectroSmartRepository
import com.example.ui.model.PermissionsManager
import com.example.ui.model.RolePermissions
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ElectroSmartViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ElectroSmartRepository

    val products: StateFlow<List<ProductEntity>>
    val imeis: StateFlow<List<ProductImeiEntity>>
    val sales: StateFlow<List<SaleEntity>>
    val saleItems: StateFlow<List<SaleItemEntity>>
    val movements: StateFlow<List<StockMovementEntity>>
    val customers: StateFlow<List<CustomerEntity>>
    val suppliers: StateFlow<List<SupplierEntity>>
    val purchases: StateFlow<List<PurchaseEntity>>
    val expenses: StateFlow<List<ExpenseEntity>>
    val users: StateFlow<List<AppUserEntity>>
    val activityLogs: StateFlow<List<ActivityLogEntity>>

    private val _currentUser = MutableStateFlow<AppUserEntity?>(null)
    val currentUser: StateFlow<AppUserEntity?> = _currentUser.asStateFlow()

    private val _activeTab = MutableStateFlow("dashboard")
    val activeTab: StateFlow<String> = _activeTab.asStateFlow()

    private val _moreModule = MutableStateFlow<String?>(null)
    val moreModule: StateFlow<String?> = _moreModule.asStateFlow()

    val currentPermissions: StateFlow<RolePermissions> = _currentUser.map { user ->
        if (user == null) PermissionsManager.CAISSIER
        else PermissionsManager.forRole(user.role)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, PermissionsManager.CAISSIER)

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ElectroSmartRepository(database.electroSmartDao())

        products = repository.products.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        imeis = repository.imeis.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        sales = repository.sales.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        saleItems = repository.saleItems.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        movements = repository.movements.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        customers = repository.customers.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        suppliers = repository.suppliers.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        purchases = repository.purchases.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        expenses = repository.expenses.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        users = repository.users.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        activityLogs = repository.activityLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
    }

    fun login(user: AppUserEntity) {
        _currentUser.value = user
        val perms = PermissionsManager.forRole(user.role)
        _activeTab.value = perms.tabs.firstOrNull() ?: "dashboard"
        _moreModule.value = null
        viewModelScope.launch {
            repository.logActivity(user.name, "Connexion", user.role)
        }
    }

    fun logout() {
        _currentUser.value = null
        _activeTab.value = "dashboard"
        _moreModule.value = null
    }

    fun setActiveTab(tab: String) {
        _activeTab.value = tab
        _moreModule.value = null
    }

    fun setMoreModule(module: String?) {
        _moreModule.value = module
    }

    fun addProduct(
        name: String,
        brand: String,
        category: String,
        ram: String,
        storage: String,
        purchasePrice: Long,
        sellingPrice: Long,
        minPrice: Long,
        stock: Int,
        minStock: Int,
        supplier: String,
        warrantyMonths: Int
    ) {
        viewModelScope.launch {
            val isPhone = category == "Téléphone"
            val id = "p${System.currentTimeMillis()}"
            val code = "SKU" + (1000 + (Math.random() * 9000).toInt())
            val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val product = ProductEntity(
                id = id,
                code = code,
                name = name,
                brand = brand,
                category = category,
                ram = if (isPhone) ram.ifEmpty { "-" } else "-",
                storage = if (isPhone) storage.ifEmpty { "-" } else "-",
                purchasePrice = purchasePrice,
                sellingPrice = sellingPrice,
                minPrice = minPrice,
                stock = stock,
                minStock = minStock,
                supplier = supplier.ifEmpty { "Non renseigné" },
                warrantyMonths = warrantyMonths,
                isPhone = isPhone,
                status = if (stock == 0) "rupture" else "disponible",
                dateEntree = todayIso,
                etat = if (isPhone) "neuf" else null
            )

            val generatedImeis = if (isPhone && stock > 0) {
                (0 until stock).map { k ->
                    "35" + (System.currentTimeMillis() % 100000000000L + k)
                }
            } else emptyList()

            repository.insertProduct(product, generatedImeis)
            val user = _currentUser.value?.name ?: "Admin"
            repository.adjustStock(id, stock, "Création produit", user)
            repository.logActivity(user, "Création produit", "$brand $name ($stock en stock)")
        }
    }

    fun adjustStock(productId: String, qtyChange: Int, reason: String) {
        viewModelScope.launch {
            val user = _currentUser.value?.name ?: "Admin"
            repository.adjustStock(productId, qtyChange, reason, user)
        }
    }

    fun recordPhysicalInventory(countedMap: Map<String, Int>) {
        viewModelScope.launch {
            val currentProducts = products.value
            val user = _currentUser.value?.name ?: "Admin"
            currentProducts.forEach { p ->
                val counted = countedMap[p.id] ?: p.stock
                val diff = counted - p.stock
                if (diff != 0) {
                    repository.adjustStock(p.id, diff, "Inventaire physique", user)
                }
            }
            repository.logActivity(user, "Inventaire physique", "Ajustements d'inventaire validés")
        }
    }

    fun checkoutSale(
        customerName: String,
        customerId: String?,
        items: List<CartLineItem>,
        paymentMethod: String,
        paidAmount: Long
    ) {
        viewModelScope.launch {
            val saleId = "s${System.currentTimeMillis()}"
            val totalSales = sales.value.size
            val invoiceNo = "F${1001 + totalSales}"
            val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val nowIso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(Date())
            val sellerName = _currentUser.value?.name ?: "Vendeur"

            val total = items.sumOf { it.unitPrice * it.qty - it.discount }
            val remaining = (total - paidAmount).coerceAtLeast(0)

            val sale = SaleEntity(
                id = saleId,
                invoiceNo = invoiceNo,
                date = todayIso,
                dateTime = nowIso,
                seller = sellerName,
                customerId = customerId,
                customerName = customerName.ifEmpty { "Client comptoir" },
                total = total,
                paid = paidAmount,
                remaining = remaining,
                paymentMethod = if (remaining > 0) "Crédit" else paymentMethod
            )

            val saleItems = items.map { line ->
                SaleItemEntity(
                    saleId = saleId,
                    productId = line.productId,
                    name = line.name,
                    qty = line.qty,
                    imei = line.imei,
                    unitPrice = line.unitPrice,
                    discount = line.discount
                )
            }

            val soldImeis = items.mapNotNull { it.imei }

            repository.recordSale(sale, saleItems, soldImeis)
        }
    }

    fun recordCreditPayment(saleId: String, amount: Long, method: String) {
        viewModelScope.launch {
            val user = _currentUser.value?.name ?: "Admin"
            repository.recordCreditPayment(saleId, amount, method, user)
        }
    }

    fun addCustomer(name: String, phone: String, address: String, notes: String) {
        viewModelScope.launch {
            val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val customer = CustomerEntity(
                id = "c${System.currentTimeMillis()}",
                name = name,
                phone = phone,
                address = address,
                notes = notes,
                createdAt = todayIso
            )
            repository.insertCustomer(customer)
            val user = _currentUser.value?.name ?: "Admin"
            repository.logActivity(user, "Ajout client", name)
        }
    }

    fun updateCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.updateCustomer(customer)
            val user = _currentUser.value?.name ?: "Admin"
            repository.logActivity(user, "Modification client", customer.name)
        }
    }

    fun addSupplier(name: String, phone: String, address: String, notes: String) {
        viewModelScope.launch {
            val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val supplier = SupplierEntity(
                id = "sup${System.currentTimeMillis()}",
                name = name,
                phone = phone,
                address = address,
                notes = notes,
                createdAt = todayIso
            )
            repository.insertSupplier(supplier)
            val user = _currentUser.value?.name ?: "Admin"
            repository.logActivity(user, "Ajout fournisseur", name)
        }
    }

    fun updateSupplier(supplier: SupplierEntity) {
        viewModelScope.launch {
            repository.updateSupplier(supplier)
            val user = _currentUser.value?.name ?: "Admin"
            repository.logActivity(user, "Modification fournisseur", supplier.name)
        }
    }

    fun recordPurchase(
        supplierId: String,
        supplierName: String,
        items: List<PurchaseCartItem>,
        paidAmount: Long
    ) {
        viewModelScope.launch {
            val purchaseId = "pu${System.currentTimeMillis()}"
            val totalPurchases = purchases.value.size
            val invoiceNo = "A${1001 + totalPurchases}"
            val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val total = items.sumOf { it.qty * it.unitCost }
            val remaining = (total - paidAmount).coerceAtLeast(0)

            val purchase = PurchaseEntity(
                id = purchaseId,
                invoiceNo = invoiceNo,
                date = todayIso,
                supplierId = supplierId,
                supplierName = supplierName,
                total = total,
                paid = paidAmount,
                remaining = remaining
            )

            val purchaseItems = items.map { line ->
                PurchaseItemEntity(
                    purchaseId = purchaseId,
                    productId = line.productId,
                    name = line.name,
                    qty = line.qty,
                    unitCost = line.unitCost
                )
            }

            val user = _currentUser.value?.name ?: "Admin"
            repository.recordPurchase(purchase, purchaseItems, user)
        }
    }

    fun addExpense(category: String, description: String, amount: Long, method: String) {
        viewModelScope.launch {
            val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val user = _currentUser.value?.name ?: "Admin"
            val expense = ExpenseEntity(
                id = "e${System.currentTimeMillis()}",
                date = todayIso,
                category = category,
                description = description,
                amount = amount,
                paymentMethod = method,
                user = user
            )
            repository.insertExpense(expense)
        }
    }

    fun deleteExpense(id: String) {
        viewModelScope.launch {
            repository.deleteExpense(id)
        }
    }

    fun addUser(name: String, role: String, pin: String) {
        viewModelScope.launch {
            val user = AppUserEntity(
                id = "u${System.currentTimeMillis()}",
                name = name,
                role = role,
                pin = pin,
                active = true
            )
            repository.insertUser(user)
            val current = _currentUser.value?.name ?: "Admin"
            repository.logActivity(current, "Ajout utilisateur", "$name ($role)")
        }
    }

    fun updateUser(user: AppUserEntity) {
        viewModelScope.launch {
            repository.updateUser(user)
            if (_currentUser.value?.id == user.id) {
                _currentUser.value = user
            }
            val current = _currentUser.value?.name ?: "Admin"
            repository.logActivity(current, "Modification utilisateur", "${user.name} (${user.role})")
        }
    }

    fun toggleUserActive(user: AppUserEntity) {
        viewModelScope.launch {
            val updated = user.copy(active = !user.active)
            repository.updateUser(updated)
            val current = _currentUser.value?.name ?: "Admin"
            repository.logActivity(current, "Statut utilisateur", "${user.name}: ${if (updated.active) "activé" else "désactivé"}")
        }
    }

    fun wipeAllData() {
        viewModelScope.launch {
            repository.wipeAllData()
            _currentUser.value = null
            _activeTab.value = "dashboard"
            _moreModule.value = null
        }
    }
}

data class CartLineItem(
    val productId: String,
    val name: String,
    val isPhone: Boolean,
    val imei: String? = null,
    val qty: Int = 1,
    val unitPrice: Long,
    val discount: Long = 0,
    val purchasePrice: Long = 0
)

data class PurchaseCartItem(
    val productId: String,
    val name: String,
    val qty: Int,
    val unitCost: Long
)
