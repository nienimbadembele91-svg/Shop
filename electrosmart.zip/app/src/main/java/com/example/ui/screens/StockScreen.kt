package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProductEntity
import com.example.data.model.StockMovementEntity
import com.example.ui.components.Pill
import com.example.ui.components.PillTone
import com.example.ui.components.StyledTextInput
import com.example.ui.components.formatCurrency
import com.example.ui.model.RolePermissions
import com.example.ui.theme.*

@Composable
fun StockScreen(
    products: List<ProductEntity>,
    movements: List<StockMovementEntity>,
    permissions: RolePermissions,
    onValidateInventory: (countedMap: Map<String, Int>) -> Unit
) {
    var selectedTab by remember { mutableStateOf("alerts") }

    val tabs = remember(permissions) {
        val list = mutableListOf(
            "alerts" to "Alertes",
            "all" to "Tout le stock",
            "history" to "Historique"
        )
        if (permissions.canDoInventory) {
            list.add("inventory" to "Inventaire")
        }
        list
    }

    val ruptureList = remember(products) { products.filter { it.stock == 0 } }
    val lowList = remember(products) { products.filter { it.stock in 1..it.minStock } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperBackground)
    ) {
        // Tab buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            tabs.forEach { (key, label) ->
                val isSelected = selectedTab == key
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) InkPrimary else CardBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                    modifier = Modifier
                        .clickable { selectedTab = key }
                        .testTag("stock_tab_$key")
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) Color.White else TextMuted,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }

        // Tab contents
        when (selectedTab) {
            "alerts" -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Out of stock
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(bottom = 4.dp)
                        ) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(RedAlert))
                            Text(
                                text = "En rupture (${ruptureList.size})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = InkPrimary
                            )
                        }
                    }

                    if (ruptureList.isEmpty()) {
                        item {
                            Text("Aucun produit en rupture.", fontSize = 12.sp, color = TextMuted)
                        }
                    } else {
                        items(ruptureList) { p ->
                            StockRow(product = p, tone = PillTone.RED)
                        }
                    }

                    // Low stock
                    item {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(bottom = 4.dp)
                        ) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(GoldDark))
                            Text(
                                text = "Stock faible (${lowList.size})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = InkPrimary
                            )
                        }
                    }

                    if (lowList.isEmpty()) {
                        item {
                            Text("Aucun produit sous le seuil d'alerte.", fontSize = 12.sp, color = TextMuted)
                        }
                    } else {
                        items(lowList) { p ->
                            StockRow(product = p, tone = PillTone.AMBER)
                        }
                    }
                }
            }

            "all" -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(products) { p ->
                        val tone = when {
                            p.stock == 0 -> PillTone.RED
                            p.stock <= p.minStock -> PillTone.AMBER
                            else -> PillTone.TEAL
                        }
                        StockRow(product = p, tone = tone)
                    }
                }
            }

            "history" -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (movements.isEmpty()) {
                        item {
                            Text("Aucun mouvement enregistré.", fontSize = 12.5.sp, color = TextMuted)
                        }
                    } else {
                        items(movements) { m ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = CardBackground,
                                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = m.productName,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextColor
                                        )
                                        val tone = when (m.type) {
                                            "entrée" -> PillTone.TEAL
                                            "vente" -> PillTone.MUTED
                                            "correction" -> PillTone.AMBER
                                            else -> PillTone.RED
                                        }
                                        Pill(text = m.type, tone = tone)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${m.reason} · ${m.user} · ${m.date.take(16).replace("T", " ")}",
                                        fontSize = 11.5.sp,
                                        color = TextMuted
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Quantité : ${m.qty} · Stock ${m.oldStock} → ${m.newStock}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = InkPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            "inventory" -> {
                PhysicalInventoryContent(
                    products = products,
                    onValidate = onValidateInventory
                )
            }
        }
    }
}

@Composable
fun StockRow(
    product: ProductEntity,
    tone: PillTone
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = CardBackground,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${product.brand} ${product.name}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextColor
                )
                Text(
                    text = "Seuil min : ${product.minStock} · Valeur : ${formatCurrency(product.stock * product.purchasePrice)}",
                    fontSize = 11.5.sp,
                    color = TextMuted
                )
            }
            Pill(
                text = "${product.stock} en stock",
                tone = tone
            )
        }
    }
}

@Composable
fun PhysicalInventoryContent(
    products: List<ProductEntity>,
    onValidate: (countedMap: Map<String, Int>) -> Unit
) {
    val counts = remember(products) {
        mutableStateMapOf<String, String>().apply {
            products.forEach { p -> put(p.id, p.stock.toString()) }
        }
    }

    var showSuccess by remember { mutableStateOf(false) }

    val diffCount = products.count { p ->
        val entered = counts[p.id]?.toIntOrNull() ?: p.stock
        entered != p.stock
    }

    val totalSystemQty = products.sumOf { it.stock }
    val totalCountedQty = products.sumOf { p ->
        counts[p.id]?.toIntOrNull() ?: p.stock
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 3 KPI cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CardBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Références", fontSize = 10.5.sp, color = TextMuted)
                        Text("${products.size}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CardBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Système", fontSize = 10.5.sp, color = TextMuted)
                        Text("$totalSystemQty", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                    }
                }

                val hasDiff = totalCountedQty != totalSystemQty
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CardBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (hasDiff) GoldAccent else BorderColor),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Compté", fontSize = 10.5.sp, color = TextMuted)
                        Text(
                            "$totalCountedQty",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (hasDiff) GoldDark else InkPrimary
                        )
                    }
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = PaperBackground,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Comptez physiquement chaque référence. Si le stock physique diffère du système, ajustez la valeur ci-dessous. $diffCount écart(s) détecté(s).",
                    fontSize = 12.sp,
                    color = TextMuted,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }

        items(products) { p ->
            val enteredStr = counts[p.id] ?: "${p.stock}"
            val enteredNum = enteredStr.toIntOrNull() ?: p.stock
            val diff = enteredNum - p.stock

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = CardBackground,
                border = androidx.compose.foundation.BorderStroke(1.dp, if (diff != 0) GoldAccent else BorderColor),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${p.brand} ${p.name}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextColor
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("En stock : ${p.stock}", fontSize = 11.sp, color = TealAccent, fontWeight = FontWeight.SemiBold)
                            if (diff != 0) {
                                Text(
                                    text = "écart ${if (diff > 0) "+$diff" else "$diff"}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldDark
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = enteredStr,
                        onValueChange = { counts[p.id] = it },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .width(68.dp)
                            .height(50.dp)
                            .testTag("inventory_count_${p.id}"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealAccent,
                            unfocusedBorderColor = BorderColor
                        )
                    )
                }
            }
        }

        item {
            Button(
                onClick = {
                    val map = products.associate { p ->
                        val entered = counts[p.id]?.toIntOrNull() ?: p.stock
                        p.id to entered
                    }
                    onValidate(map)
                    showSuccess = true
                },
                enabled = diffCount > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = TealAccent,
                    disabledContainerColor = Color(0xFFD8D3C6)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .padding(top = 6.dp)
                    .testTag("validate_inventory_button")
            ) {
                Text(
                    text = if (showSuccess) "Inventaire validé ✓" else "Valider l'inventaire ($diffCount écarts)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp
                )
            }
        }
    }
}
