package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProductEntity
import com.example.data.model.ProductImeiEntity
import com.example.ui.components.*
import com.example.ui.model.RolePermissions
import com.example.ui.theme.*

val BRANDS = listOf("TECNO", "Infinix", "itel", "Samsung", "Xiaomi", "Apple", "Nokia", "Kgtel", "Villaon", "Honor")
val CATEGORIES = listOf("Téléphone", "Accessoire")

@Composable
fun ProductsScreen(
    products: List<ProductEntity>,
    imeis: List<ProductImeiEntity>,
    permissions: RolePermissions,
    onAddProduct: (
        name: String, brand: String, category: String, ram: String, storage: String,
        purchasePrice: Long, sellingPrice: Long, minPrice: Long, stock: Int, minStock: Int,
        supplier: String, warrantyMonths: Int
    ) -> Unit,
    onAdjustStock: (productId: String, qtyChange: Int, reason: String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Tous") }
    var selectedProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val filteredProducts = remember(products, imeis, searchQuery, selectedCategory) {
        val q = searchQuery.trim().lowercase()
        products.filter { p ->
            val matchesCategory = selectedCategory == "Tous" || p.category == selectedCategory
            val matchesQuery = if (q.isEmpty()) true else {
                val fullName = "${p.brand} ${p.name} ${p.code}".lowercase()
                val hasImeiMatch = imeis.filter { it.productId == p.id }.any { it.imei.contains(q) }
                fullName.contains(q) || hasImeiMatch
            }
            matchesCategory && matchesQuery
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperBackground)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Search and Category Chips
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            ) {
                ElectroSearchField(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    placeholder = "Nom, marque, IMEI, code..."
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val cats = listOf("Tous") + CATEGORIES
                    cats.forEach { cat ->
                        val isSelected = selectedCategory == cat
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = if (isSelected) InkPrimary else CardBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                            modifier = Modifier
                                .clickable { selectedCategory = cat }
                                .testTag("product_category_chip_$cat")
                        ) {
                            Text(
                                text = cat,
                                color = if (isSelected) Color.White else TextMuted,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Products list
            if (filteredProducts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Aucun produit ne correspond à la recherche.",
                        color = TextMuted,
                        fontSize = 13.5.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredProducts, key = { it.id }) { product ->
                        ProductItemCard(
                            product = product,
                            onClick = { selectedProduct = product }
                        )
                    }
                }
            }
        }

        // FAB to add product
        if (permissions.canManageProducts) {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = TealAccent,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 20.dp, bottom = 80.dp)
                    .testTag("add_product_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Ajouter un produit")
            }
        }
    }

    // Product Detail Sheet
    if (selectedProduct != null) {
        val p = selectedProduct!!
        val productImeis = imeis.filter { it.productId == p.id }

        ProductDetailSheet(
            product = p,
            imeis = productImeis,
            canAdjust = permissions.canAdjustStock,
            onClose = { selectedProduct = null },
            onAdjust = { qty, reason ->
                onAdjustStock(p.id, qty, reason)
                selectedProduct = null
            }
        )
    }

    // Add Product Form
    if (showAddDialog) {
        AddProductSheet(
            onClose = { showAddDialog = false },
            onSave = { name, brand, cat, ram, storage, pPrice, sPrice, mPrice, stock, minStock, supp, war ->
                onAddProduct(name, brand, cat, ram, storage, pPrice, sPrice, mPrice, stock, minStock, supp, war)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun ProductItemCard(
    product: ProductEntity,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = CardBackground,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("product_item_${product.id}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(InkPrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PhoneAndroid,
                    contentDescription = null,
                    tint = GoldAccent,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${product.brand} ${product.name}",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = formatCurrency(product.sellingPrice),
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkPrimary
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))
                val subtitle = buildString {
                    append(product.category)
                    if (product.isPhone && product.ram != "-") {
                        append(" · ${product.ram}/${product.storage}")
                    }
                    append(" · ${product.code}")
                }
                Text(
                    text = subtitle,
                    fontSize = 11.5.sp,
                    color = TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val tone = when {
                        product.stock == 0 -> PillTone.RED
                        product.stock <= product.minStock -> PillTone.AMBER
                        else -> PillTone.TEAL
                    }
                    val text = when {
                        product.stock == 0 -> "Rupture"
                        else -> "${product.stock} en stock"
                    }
                    Pill(text = text, tone = tone)
                    if (product.isPhone) {
                        Pill(text = "IMEI suivi", tone = PillTone.MUTED)
                    }
                }
            }
        }
    }
}

@Composable
fun ProductDetailSheet(
    product: ProductEntity,
    imeis: List<ProductImeiEntity>,
    canAdjust: Boolean,
    onClose: () -> Unit,
    onAdjust: (qty: Int, reason: String) -> Unit
) {
    var adjustQty by remember { mutableStateOf(1) }
    var adjustReason by remember { mutableStateOf("Réapprovisionnement") }

    BottomSheetContainer(
        title = "${product.brand} ${product.name}",
        onClose = onClose
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            // Badges
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 14.dp)) {
                Pill(
                    text = "${product.stock} en stock",
                    tone = if (product.stock == 0) PillTone.RED else PillTone.TEAL
                )
                Pill(text = product.code, tone = PillTone.MUTED)
                Pill(text = product.category, tone = PillTone.MUTED)
            }

            // Specs grid
            val specs = listOf(
                "Prix d'achat" to formatCurrency(product.purchasePrice),
                "Prix de vente" to formatCurrency(product.sellingPrice),
                "Prix minimum" to formatCurrency(product.minPrice),
                "Fournisseur" to product.supplier,
                "Garantie" to "${product.warrantyMonths} mois",
                "Seuil minimum" to "${product.minStock}"
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 16.dp)) {
                specs.chunked(2).forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        row.forEach { (label, value) ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = PaperBackground,
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(label, fontSize = 10.5.sp, color = TextMuted)
                                    Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextColor)
                                }
                            }
                        }
                    }
                }
            }

            // IMEIs section if phone
            if (product.isPhone) {
                val inStockCount = imeis.count { it.status == "en stock" }
                Text(
                    text = "Unités IMEI ($inStockCount disponibles)",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = InkPrimary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 140.dp)
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 16.dp)
                ) {
                    if (imeis.isEmpty()) {
                        Text("Aucun numéro IMEI enregistré.", fontSize = 12.sp, color = TextMuted)
                    } else {
                        imeis.forEach { im ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = PaperBackground,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(im.imei, fontSize = 12.sp, color = TextColor)
                                    Pill(
                                        text = im.status,
                                        tone = if (im.status == "en stock") PillTone.TEAL else PillTone.MUTED
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Adjust stock section
            HorizontalDivider(color = BorderColor)
            Spacer(modifier = Modifier.height(14.dp))

            if (canAdjust) {
                Text(
                    text = "Ajuster le stock",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = InkPrimary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 10.dp)
                ) {
                    IconButton(
                        onClick = { adjustQty = (adjustQty - 1).coerceAtLeast(1) },
                        modifier = Modifier
                            .size(36.dp)
                            .background(CardBackground, RoundedCornerShape(8.dp))
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Diminuer")
                    }

                    Text(
                        text = "$adjustQty",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkPrimary
                    )

                    IconButton(
                        onClick = { adjustQty += 1 },
                        modifier = Modifier
                            .size(36.dp)
                            .background(CardBackground, RoundedCornerShape(8.dp))
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Augmenter")
                    }
                }

                // Reason dropdown or buttons
                val reasons = listOf("Réapprovisionnement", "Correction d'inventaire", "Retour fournisseur", "Produit endommagé")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    reasons.forEach { r ->
                        val isSelected = adjustReason == r
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) InkPrimary else PaperBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                            modifier = Modifier.clickable { adjustReason = r }
                        ) {
                            Text(
                                text = r,
                                fontSize = 11.5.sp,
                                color = if (isSelected) Color.White else TextColor,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { onAdjust(-adjustQty, adjustReason) },
                        colors = ButtonDefaults.buttonColors(containerColor = RedAlert),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Retirer (-$adjustQty)", fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onAdjust(adjustQty, adjustReason) },
                        colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Ajouter (+$adjustQty)", fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Text(
                    text = "Votre rôle ne permet pas de modifier le stock.",
                    fontSize = 12.sp,
                    color = TextMuted
                )
            }
        }
    }
}

@Composable
fun AddProductSheet(
    onClose: () -> Unit,
    onSave: (
        name: String, brand: String, category: String, ram: String, storage: String,
        purchasePrice: Long, sellingPrice: Long, minPrice: Long, stock: Int, minStock: Int,
        supplier: String, warrantyMonths: Int
    ) -> Unit
) {
    var category by remember { mutableStateOf("Téléphone") }
    var brand by remember { mutableStateOf(BRANDS.first()) }
    var name by remember { mutableStateOf("") }
    var ram by remember { mutableStateOf("4Go") }
    var storage by remember { mutableStateOf("64Go") }
    var purchasePriceStr by remember { mutableStateOf("") }
    var sellingPriceStr by remember { mutableStateOf("") }
    var minPriceStr by remember { mutableStateOf("") }
    var stockStr by remember { mutableStateOf("") }
    var minStockStr by remember { mutableStateOf("3") }
    var supplier by remember { mutableStateOf("") }
    var warrantyMonthsStr by remember { mutableStateOf("12") }

    val isPhone = category == "Téléphone"
    val isValid = name.isNotBlank() && purchasePriceStr.toLongOrNull() != null &&
            sellingPriceStr.toLongOrNull() != null && stockStr.toIntOrNull() != null

    BottomSheetContainer(
        title = "Nouveau produit",
        onClose = onClose,
        footer = {
            Button(
                onClick = {
                    if (isValid) {
                        val pPrice = purchasePriceStr.toLongOrNull() ?: 0L
                        val sPrice = sellingPriceStr.toLongOrNull() ?: 0L
                        val mPrice = minPriceStr.toLongOrNull() ?: sPrice
                        val stk = stockStr.toIntOrNull() ?: 0
                        val minStk = minStockStr.toIntOrNull() ?: 3
                        val war = warrantyMonthsStr.toIntOrNull() ?: 0
                        onSave(name, brand, category, ram, storage, pPrice, sPrice, mPrice, stk, minStk, supplier, war)
                    }
                },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(
                    containerColor = TealAccent,
                    disabledContainerColor = Color(0xFFD8D3C6)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_product_button")
            ) {
                Text("Enregistrer le produit", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            // Category selector
            FormField(label = "Catégorie") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CATEGORIES.forEach { c ->
                        val isSelected = category == c
                        Button(
                            onClick = { category = c },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) InkPrimary else CardBackground,
                                contentColor = if (isSelected) Color.White else TextColor
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(c, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                }
            }

            // Brand selector
            FormField(label = "Marque") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    BRANDS.forEach { b ->
                        val isSelected = brand == b
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) InkPrimary else PaperBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                            modifier = Modifier.clickable { brand = b }
                        ) {
                            Text(
                                text = b,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.White else TextColor,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Model name
            FormField(label = "Nom du modèle *") {
                StyledTextInput(
                    value = name,
                    onValueChange = { name = it },
                    placeholder = "ex : Camon 20",
                    modifier = Modifier.testTag("product_name_input")
                )
            }

            // RAM and Storage for phones
            if (isPhone) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        FormField(label = "RAM") {
                            StyledTextInput(value = ram, onValueChange = { ram = it }, placeholder = "6Go")
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        FormField(label = "Stockage") {
                            StyledTextInput(value = storage, onValueChange = { storage = it }, placeholder = "128Go")
                        }
                    }
                }
            }

            // Prices
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    FormField(label = "Prix d'achat (F CFA) *") {
                        StyledTextInput(
                            value = purchasePriceStr,
                            onValueChange = { purchasePriceStr = it },
                            placeholder = "95000",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.testTag("product_purchase_price_input")
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    FormField(label = "Prix de vente (F CFA) *") {
                        StyledTextInput(
                            value = sellingPriceStr,
                            onValueChange = { sellingPriceStr = it },
                            placeholder = "125000",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.testTag("product_selling_price_input")
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    FormField(label = "Prix minimum autorisé") {
                        StyledTextInput(
                            value = minPriceStr,
                            onValueChange = { minPriceStr = it },
                            placeholder = "115000",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    FormField(label = "Garantie (mois)") {
                        StyledTextInput(
                            value = warrantyMonthsStr,
                            onValueChange = { warrantyMonthsStr = it },
                            placeholder = "12",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                }
            }

            // Stock quantities
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    FormField(label = "Quantité en stock *") {
                        StyledTextInput(
                            value = stockStr,
                            onValueChange = { stockStr = it },
                            placeholder = "6",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.testTag("product_stock_input")
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    FormField(label = "Seuil minimum") {
                        StyledTextInput(
                            value = minStockStr,
                            onValueChange = { minStockStr = it },
                            placeholder = "3",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                }
            }

            // Supplier
            FormField(label = "Fournisseur") {
                StyledTextInput(
                    value = supplier,
                    onValueChange = { supplier = it },
                    placeholder = "Nom du fournisseur"
                )
            }

            if (isPhone) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = PaperBackground,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                ) {
                    Text(
                        text = "Des numéros IMEI seront générés automatiquement pour chaque unité en stock.",
                        fontSize = 11.5.sp,
                        color = TextMuted,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}
