package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ActivityLogEntity
import com.example.ui.components.Pill
import com.example.ui.components.PillTone
import com.example.ui.theme.*

@Composable
fun AuditScreen(
    auditLogs: List<ActivityLogEntity>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperBackground)
    ) {
        if (auditLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Aucune action enregistrée dans le journal.",
                    color = TextMuted,
                    fontSize = 13.5.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(auditLogs.reversed(), key = { it.id }) { log ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CardBackground,
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("audit_item_${log.id}")
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = log.action,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextColor
                                )
                                val tone = when {
                                    log.action.contains("Vente", ignoreCase = true) -> PillTone.TEAL
                                    log.action.contains("Stock", ignoreCase = true) -> PillTone.AMBER
                                    log.action.contains("Connexion", ignoreCase = true) -> PillTone.MUTED
                                    log.action.contains("Suppression", ignoreCase = true) -> PillTone.RED
                                    else -> PillTone.MUTED
                                }
                                Pill(text = log.user, tone = tone)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = log.details,
                                fontSize = 12.sp,
                                color = TextColor
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${log.user} · ${log.date}",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

