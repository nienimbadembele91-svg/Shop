package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

data class NavItem(
    val key: String,
    val label: String,
    val icon: ImageVector
)

val ALL_NAV_ITEMS = listOf(
    NavItem("dashboard", "Accueil", Icons.Default.Home),
    NavItem("sales", "Ventes", Icons.Default.ShoppingCart),
    NavItem("stock", "Stock", Icons.Default.Inventory2),
    NavItem("products", "Produits", Icons.Default.PhoneAndroid),
    NavItem("clients", "Clients", Icons.Default.People),
    NavItem("more", "Plus", Icons.Default.Settings)
)

@Composable
fun ElectroBottomNav(
    activeTab: String,
    onTabSelected: (String) -> Unit,
    allowedTabs: List<String>,
    modifier: Modifier = Modifier
) {
    val items = ALL_NAV_ITEMS.filter { allowedTabs.contains(it.key) }

    Surface(
        color = CardBackground,
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        shadowElevation = 8.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEach { item ->
                val isSelected = activeTab == item.key
                val tint = if (isSelected) TealAccent else TextMuted
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onTabSelected(item.key) }
                        .padding(vertical = 4.dp)
                        .testTag("nav_${item.key}")
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        tint = tint,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = item.label,
                        color = tint,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}
