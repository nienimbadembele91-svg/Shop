package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.CartLineItem

val PAYMENT_METHODS = listOf("Espèces", "Orange Money", "Moov Money", "Carte bancaire", "Virement")

@Composable
fun SalesScreen(
    products: List<ProductEntity>,
    imeis: List<ProductImeiEntity>,
    sales: List<SaleEntity>,
    saleItems: List<SaleItemEntity>,
    customers: List<CustomerEntity>,
    onCheckout: (
        customerName: String,
        customerId: String?,
        items: List<CartLineItem>,
        paymentMethod: String,
        paidAmount: Long
    ) -> Unit,
    onQuickAddCustomer: (name: String) -> Unit
) {
    var viewMode by remember { mutableStateOf("new") } // "new" | "history"
    var searchQuery by remember { mutableStateOf("") }
    val cart = remember { mutableStateListOf<CartLineItem>() }
    var customerName by remember { mutableStateOf("") }
    var selectedCustomerId by remember { mutableStateOf<String?>(null) }
    var showClientPicker by remember { mutableStateOf(false) }
    var selectedPaymentMethod by remember { mutableStateOf("Espèces") }
    var paidAmountStr by remember { mutableStateOf("") }
    var displayedReceiptSale by remember { mutableStateOf<SaleEntity?>(null) }

    val searchResults = remember(products, imeis, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) emptyList()
        else {
            products.filter { p ->
                p.stock > 0 && (
                    "${p.brand} ${p.name}".lowercase().contains(q) ||
                    imeis.filter { it.productId == p.id }.any { it.imei.contains(q) }
                )
            }
        }
    }

    fun addToCart(p: ProductEntity) {
        if (p.isPhone) {
            val alreadyUsedImeis = cart.filter { it.productId == p.id }.mapNotNull { it.imei }
            val availableImei = imeis.firstOrNull { it.productId == p.id && it.status == "en stock" && !alreadyUsedImeis.contains(it.imei) }
            cart.add(
                CartLineItem(
                    productId = p.id,
                    name = "${p.brand} ${p.name}",
                    isPhone = true,
                    imei = availableImei?.imei,
                    qty = 1,
                    unitPrice = p.sellingPrice,
                    discount = 0,
                    purchasePrice = p.purchasePrice
                )
            )
        } else {
            val existingIdx = cart.indexOfFirst { it.productId == p.id }
            if (existingIdx >= 0) {
                val current = cart[existingIdx]
                cart[existingIdx] = current.copy(qty = current.qty + 1)
            } else {
                cart.add(
                    CartLineItem(
                        productId = p.id,
                        name = "${p.brand} ${p.name}",
                        isPhone = false,
                        imei = null,
                        qty = 1,
                        unitPrice = p.sellingPrice,
                        discount = 0,
                        purchasePrice = p.purchasePrice
                    )
                )
            }
        }
        searchQuery = ""
    }

    val cartTotal = cart.sumOf { (it.unitPrice * it.qty) - it.discount }
    val paidAmount = if (paidAmountStr.isBlank()) cartTotal else (paidAmountStr.toLongOrNull() ?: cartTotal)
    val remaining = (cartTotal - paidAmount).coerceAtLeast(0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperBackground)
    ) {
        // Toggle new sale / history
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("new" to "Nouvelle vente", "history" to "Historique des ventes").forEach { (key, label) ->
                val isSelected = viewMode == key
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) InkPrimary else CardBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewMode = key }
                        .testTag("sales_tab_$key")
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) Color.White else TextMuted,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(vertical = 9.dp)
                    )
                }
            }
        }

        if (viewMode == "history") {
            SalesHistoryList(
                sales = sales,
                onViewReceipt = { displayedReceiptSale = it }
            )
        } else {
            // New Sale Mode
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Search & Scan Bar
                item {
                    ElectroSearchField(
                        query = searchQuery,
                        onQueryChange = { searchQuery = it },
                        placeholder = "Rechercher un produit ou scanner l'IMEI"
                    )

                    // Results dropdown
                    if (searchResults.isNotEmpty()) {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = CardBackground),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp)
                        ) {
                            Column(modifier = Modifier.padding(6.dp)) {
                                searchResults.forEach { p ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { addToCart(p) }
                                            .padding(horizontal = 10.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("${p.brand} ${p.name}", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                                            Text("${p.stock} en stock · ${formatCurrency(p.sellingPrice)}", fontSize = 11.sp, color = TextMuted)
                                        }
                                        Icon(Icons.Default.Add, contentDescription = "Ajouter", tint = TealAccent, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                // Cart Header
                item {
                    Text(
                        text = "Panier (${cart.size})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkPrimary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                if (cart.isEmpty()) {
                    item {
                        Text(
                            text = "Ajoutez un produit pour commencer la vente.",
                            fontSize = 12.5.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                } else {
                    itemsIndexed(cart) { idx, line ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = CardBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(line.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextColor)
                                    IconButton(
                                        onClick = { cart.removeAt(idx) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "Supprimer", tint = TextMuted, modifier = Modifier.size(16.dp))
                                    }
                                }

                                if (line.imei != null) {
                                    Text("IMEI : ${line.imei}", fontSize = 11.sp, color = TextMuted)
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (!line.isPhone) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            IconButton(
                                                onClick = {
                                                    if (line.qty > 1) cart[idx] = line.copy(qty = line.qty - 1)
                                                },
                                                modifier = Modifier.size(28.dp).background(PaperBackground, RoundedCornerShape(6.dp))
                                            ) {
                                                Icon(Icons.Default.Remove, contentDescription = "Moins", modifier = Modifier.size(14.dp))
                                            }
                                            Text("${line.qty}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            IconButton(
                                                onClick = { cart[idx] = line.copy(qty = line.qty + 1) },
                                                modifier = Modifier.size(28.dp).background(PaperBackground, RoundedCornerShape(6.dp))
                                            ) {
                                                Icon(Icons.Default.Add, contentDescription = "Plus", modifier = Modifier.size(14.dp))
                                            }
                                        }
                                    } else {
                                        Text("1 unité", fontSize = 12.sp, color = TextMuted)
                                    }

                                    Spacer(modifier = Modifier.weight(1f))

                                    // Discount input
                                    OutlinedTextField(
                                        value = if (line.discount == 0L) "" else "${line.discount}",
                                        onValueChange = {
                                            val d = it.toLongOrNull() ?: 0L
                                            cart[idx] = line.copy(discount = d)
                                        },
                                        placeholder = { Text("Remise", fontSize = 11.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.width(80.dp).height(46.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = TealAccent,
                                            unfocusedBorderColor = BorderColor
                                        )
                                    )

                                    Spacer(modifier = Modifier.width(8.dp))

                                    val lineSubtotal = (line.unitPrice * line.qty) - line.discount
                                    Text(
                                        text = formatCurrency(lineSubtotal),
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = InkPrimary
                                    )
                                }
                            }
                        }
                    }

                    // Customer Selection
                    item {
                        FormField(label = "Client (optionnel)") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = customerName,
                                    onValueChange = {
                                        customerName = it
                                        selectedCustomerId = null
                                    },
                                    placeholder = { Text("Nom du client (comptoir)", fontSize = 13.sp) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TealAccent,
                                        unfocusedBorderColor = BorderColor
                                    ),
                                    modifier = Modifier.weight(1f).testTag("customer_name_input")
                                )

                                Button(
                                    onClick = { showClientPicker = true },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CardBackground,
                                        contentColor = TealAccent
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor)
                                ) {
                                    Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Fiche", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Payment Method
                    item {
                        FormField(label = "Mode de paiement") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                PAYMENT_METHODS.forEach { m ->
                                    val isSelected = selectedPaymentMethod == m
                                    Surface(
                                        shape = RoundedCornerShape(999.dp),
                                        color = if (isSelected) InkPrimary else CardBackground,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                                        modifier = Modifier.clickable { selectedPaymentMethod = m }
                                    ) {
                                        Text(
                                            text = m,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isSelected) Color.White else TextColor,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Paid Amount & Credit Notice
                    item {
                        FormField(label = "Montant payé (Total : ${formatCurrency(cartTotal)})") {
                            StyledTextInput(
                                value = paidAmountStr,
                                onValueChange = { paidAmountStr = it },
                                placeholder = "$cartTotal",
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.testTag("paid_amount_input")
                            )
                        }

                        if (remaining > 0) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = AmberSoft,
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                            ) {
                                Text(
                                    text = "Reste à payer : ${formatCurrency(remaining)} — enregistré comme créance client.",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = GoldDark,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                    }

                    // Checkout Button
                    item {
                        Button(
                            onClick = {
                                val currentItems = cart.toList()
                                onCheckout(customerName, selectedCustomerId, currentItems, selectedPaymentMethod, paidAmount)
                                cart.clear()
                                customerName = ""
                                selectedCustomerId = null
                                paidAmountStr = ""
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .padding(top = 6.dp)
                                .testTag("complete_checkout_button")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Encaisser ${formatCurrency(cartTotal)}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    // Client Picker Dialog
    if (showClientPicker) {
        ClientPickerDialog(
            customers = customers,
            onClose = { showClientPicker = false },
            onSelect = { c ->
                customerName = c.name
                selectedCustomerId = c.id
                showClientPicker = false
            },
            onQuickAdd = { name ->
                onQuickAddCustomer(name)
                customerName = name
                showClientPicker = false
            }
        )
    }

    // Receipt View
    if (displayedReceiptSale != null) {
        val s = displayedReceiptSale!!
        val itemsForSale = saleItems.filter { it.saleId == s.id }
        ReceiptDialog(
            sale = s,
            items = itemsForSale,
            onClose = { displayedReceiptSale = null }
        )
    }
}

@Composable
fun SalesHistoryList(
    sales: List<SaleEntity>,
    onViewReceipt: (SaleEntity) -> Unit
) {
    if (sales.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
            Text("Aucune vente enregistrée.", fontSize = 13.5.sp, color = TextMuted)
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(sales, key = { it.id }) { sale ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CardBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = "${sale.invoiceNo} · ${sale.customerName}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextColor
                                )
                                Text(
                                    text = "${sale.date} · Vendeur : ${sale.seller}",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                            Pill(
                                text = if (sale.remaining > 0) "Crédit" else "Payée",
                                tone = if (sale.remaining > 0) PillTone.AMBER else PillTone.TEAL
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = formatCurrency(sale.total),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = InkPrimary
                            )

                            OutlinedButton(
                                onClick = { onViewReceipt(sale) },
                                shape = RoundedCornerShape(999.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp).testTag("view_invoice_${sale.id}")
                            ) {
                                Icon(Icons.Default.Receipt, contentDescription = null, tint = TealAccent, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Facture (PDF)", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = TealAccent)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ClientPickerDialog(
    customers: List<CustomerEntity>,
    onClose: () -> Unit,
    onSelect: (CustomerEntity) -> Unit,
    onQuickAdd: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(customers, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) customers
        else customers.filter { it.name.lowercase().contains(q) }
    }

    BottomSheetContainer(
        title = "Sélectionner un client",
        onClose = onClose
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            ElectroSearchField(query = query, onQueryChange = { query = it }, placeholder = "Rechercher un client...")

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = TealSoft,
                border = androidx.compose.foundation.BorderStroke(1.dp, TealAccent.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onQuickAdd(query.ifEmpty { "Nouveau client" }) }
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = TealAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Nouveau client ${if (query.isNotEmpty()) "\"$query\"" else ""}",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = TealAccent
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp)
            ) {
                items(filtered) { c ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = CardBackground,
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(c) }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(c.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                if (c.phone.isNotEmpty()) {
                                    Text(c.phone, fontSize = 11.sp, color = TextMuted)
                                }
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReceiptDialog(
    sale: SaleEntity,
    items: List<SaleItemEntity>,
    onClose: () -> Unit
) {
    BottomSheetContainer(
        title = "Facture ${sale.invoiceNo}",
        onClose = onClose,
        footer = {
            Button(
                onClick = onClose,
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text("Fermer", fontWeight = FontWeight.Bold)
            }
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            // Receipt Card
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = CardBackground,
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ELECTRO_SMART",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkPrimary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "Bamako, Mali · Tél : +223 XX XX XX XX",
                        fontSize = 11.sp,
                        color = TextMuted,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                    )

                    HorizontalDivider(color = BorderColor)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Facture ${sale.invoiceNo}", fontSize = 11.5.sp, color = TextMuted)
                        Text(sale.dateTime.take(16).replace("T", " "), fontSize = 11.5.sp, color = TextMuted)
                    }
                    HorizontalDivider(color = BorderColor)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Client : ${sale.customerName} · Vendeur : ${sale.seller}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(10.dp))

                    items.forEach { it ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val detail = "${it.qty}× ${it.name}${if (it.imei != null) " (IMEI ${it.imei})" else ""}"
                            Text(detail, fontSize = 12.sp, modifier = Modifier.weight(1f, fill = false))
                            Text(formatCurrency(it.unitPrice * it.qty - it.discount), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = BorderColor)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Total", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                        Text(formatCurrency(sale.total), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Payé (${sale.paymentMethod})", fontSize = 12.sp, color = TextMuted)
                        Text(formatCurrency(sale.paid), fontSize = 12.sp, color = TextMuted)
                    }

                    if (sale.remaining > 0) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Reste à payer", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RedAlert)
                            Text(formatCurrency(sale.remaining), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RedAlert)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Merci de votre confiance !",
                        fontSize = 11.sp,
                        color = TextMuted,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
