package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExpenseEntity
import com.example.ui.components.*
import com.example.ui.model.RolePermissions
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

val EXPENSE_CATEGORIES = listOf(
    "Loyer", "Électricité", "Internet", "Transport", "Salaire",
    "Communication", "Réparation", "Emballage", "Marketing", "Frais bancaires", "Autres"
)

@Composable
fun ExpensesScreen(
    expenses: List<ExpenseEntity>,
    permissions: RolePermissions,
    onAddExpense: (category: String, description: String, amount: Long, method: String) -> Unit,
    onDeleteExpense: (id: String) -> Unit
) {
    var selectedPeriod by remember { mutableStateOf("today") }
    var showAddDialog by remember { mutableStateOf(false) }

    val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    val weekAgoStr = remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -6)
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
    }
    val currentMonthStr = remember { todayStr.take(7) }

    val filteredExpenses = remember(expenses, selectedPeriod) {
        when (selectedPeriod) {
            "today" -> expenses.filter { it.date == todayStr }
            "week" -> expenses.filter { it.date >= weekAgoStr }
            "month" -> expenses.filter { it.date.startsWith(currentMonthStr) }
            else -> expenses
        }
    }

    val totalExpenses = filteredExpenses.sumOf { it.amount }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperBackground)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Period filter
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("today" to "Aujourd'hui", "week" to "7 jours", "month" to "Ce mois").forEach { (key, label) ->
                    val isSelected = selectedPeriod == key
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) InkPrimary else CardBackground,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPeriod = key }
                            .testTag("expense_period_$key")
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.White else TextMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }
            }

            // Total card
            Box(modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = CardBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Total des dépenses", fontSize = 12.sp, color = TextMuted, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(formatCurrency(totalExpenses), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = RedAlert)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Expenses list
            if (filteredExpenses.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("Aucune dépense sur cette période.", fontSize = 13.sp, color = TextMuted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredExpenses.reversed(), key = { it.id }) { e ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = CardBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Pill(text = e.category, tone = PillTone.MUTED)
                                        Text(e.date, fontSize = 11.sp, color = TextMuted)
                                    }
                                    if (e.description.isNotEmpty()) {
                                        Text(e.description, fontSize = 12.5.sp, color = TextColor, modifier = Modifier.padding(top = 3.dp))
                                    }
                                    Text("${e.paymentMethod} · ${e.user}", fontSize = 11.sp, color = TextMuted, modifier = Modifier.padding(top = 2.dp))
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(formatCurrency(e.amount), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextColor)
                                    if (permissions.canManageExpenses) {
                                        IconButton(onClick = { onDeleteExpense(e.id) }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Close, contentDescription = "Supprimer", tint = TextMuted, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (permissions.canManageExpenses) {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = TealAccent,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 20.dp, bottom = 80.dp)
                    .testTag("add_expense_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter une dépense")
            }
        }
    }

    if (showAddDialog) {
        ExpenseFormDialog(
            onClose = { showAddDialog = false },
            onSave = { cat, desc, amt, meth ->
                onAddExpense(cat, desc, amt, meth)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun ExpenseFormDialog(
    onClose: () -> Unit,
    onSave: (category: String, description: String, amount: Long, method: String) -> Unit
) {
    var amountStr by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(EXPENSE_CATEGORIES.first()) }
    var description by remember { mutableStateOf("") }
    var selectedMethod by remember { mutableStateOf("Espèces") }

    val amount = amountStr.toLongOrNull() ?: 0L
    val isValid = amount > 0

    BottomSheetContainer(
        title = "Nouvelle dépense",
        onClose = onClose,
        footer = {
            Button(
                onClick = { if (isValid) onSave(selectedCategory, description, amount, selectedMethod) },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_expense_button")
            ) {
                Text("Enregistrer la dépense", fontWeight = FontWeight.Bold)
            }
        }
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            FormField(label = "Montant (F CFA) *") {
                StyledTextInput(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    placeholder = "15000",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.testTag("expense_amount_input")
                )
            }

            FormField(label = "Catégorie") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    EXPENSE_CATEGORIES.forEach { c ->
                        val isSelected = selectedCategory == c
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = if (isSelected) InkPrimary else CardBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                            modifier = Modifier.clickable { selectedCategory = c }
                        ) {
                            Text(
                                text = c,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.White else TextColor,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            FormField(label = "Description") {
                StyledTextInput(
                    value = description,
                    onValueChange = { description = it },
                    placeholder = "ex : Facture EDM de septembre"
                )
            }

            FormField(label = "Mode de paiement") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PAYMENT_METHODS.forEach { m ->
                        val isSelected = selectedMethod == m
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = if (isSelected) InkPrimary else CardBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                            modifier = Modifier.clickable { selectedMethod = m }
                        ) {
                            Text(
                                text = m,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.White else TextColor,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
