package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

val REPORT_TYPES = listOf(
    "sales" to "Ventes",
    "stock" to "Stock",
    "top_products" to "Top produits",
    "brands" to "Par marque",
    "expenses" to "Dépenses",
    "debts_clients" to "Créances",
    "debts_suppliers" to "Dettes fourn."
)

@Composable
fun ReportsScreen(
    sales: List<SaleEntity>,
    saleItems: List<SaleItemEntity>,
    products: List<ProductEntity>,
    expenses: List<ExpenseEntity>,
    purchases: List<PurchaseEntity>,
    customers: List<CustomerEntity>,
    suppliers: List<SupplierEntity>
) {
    val context = LocalContext.current
    var selectedType by remember { mutableStateOf("sales") }
    var selectedPeriod by remember { mutableStateOf("month") }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportContent by remember { mutableStateOf("") }
    var copiedToClipboard by remember { mutableStateOf(false) }

    val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    val weekAgoStr = remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -6)
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
    }
    val currentMonthStr = remember { todayStr.take(7) }

    val filteredSales = remember(sales, selectedPeriod) {
        when (selectedPeriod) {
            "week" -> sales.filter { it.date >= weekAgoStr }
            "month" -> sales.filter { it.date.startsWith(currentMonthStr) }
            else -> sales
        }
    }

    val filteredExpenses = remember(expenses, selectedPeriod) {
        when (selectedPeriod) {
            "week" -> expenses.filter { it.date >= weekAgoStr }
            "month" -> expenses.filter { it.date.startsWith(currentMonthStr) }
            else -> expenses
        }
    }

    fun generateCsv() {
        val sb = StringBuilder()
        when (selectedType) {
            "sales" -> {
                sb.appendLine("Facture,Date,Client,Vendeur,Mode,Total,Paye,Reste")
                filteredSales.forEach { s ->
                    sb.appendLine("${s.invoiceNo},${s.date},\"${s.customerName}\",\"${s.seller}\",${s.paymentMethod},${s.total},${s.paid},${s.remaining}")
                }
            }
            "stock" -> {
                sb.appendLine("Code,Marque,Modele,Categorie,Stock,PrixAchat,PrixVente,ValeurStock")
                products.forEach { p ->
                    sb.appendLine("${p.code},${p.brand},\"${p.name}\",${p.category},${p.stock},${p.purchasePrice},${p.sellingPrice},${p.stock * p.purchasePrice}")
                }
            }
            "expenses" -> {
                sb.appendLine("Date,Categorie,Description,Montant,Mode,Utilisateur")
                filteredExpenses.forEach { e ->
                    sb.appendLine("${e.date},${e.category},\"${e.description}\",${e.amount},${e.paymentMethod},${e.user}")
                }
            }
            "debts_clients" -> {
                sb.appendLine("Facture,Date,Client,Telephone,Total,Paye,Creance")
                sales.filter { it.remaining > 0 }.forEach { s ->
                    val c = customers.find { it.id == s.customerId }
                    sb.appendLine("${s.invoiceNo},${s.date},\"${s.customerName}\",${c?.phone ?: ""},${s.total},${s.paid},${s.remaining}")
                }
            }
            else -> {
                sb.appendLine("Rapport,${selectedType},Date,${todayStr}")
            }
        }
        exportContent = sb.toString()
        showExportDialog = true
        copiedToClipboard = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperBackground)
    ) {
        // Report Type Horizontal Scroll
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            REPORT_TYPES.forEach { (key, label) ->
                val isSelected = selectedType == key
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = if (isSelected) InkPrimary else CardBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                    modifier = Modifier
                        .clickable { selectedType = key }
                        .testTag("report_type_$key")
                ) {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isSelected) Color.White else TextMuted,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Period filter & Export button row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("week" to "7j", "month" to "Mois", "all" to "Tout").forEach { (key, label) ->
                    val isSelected = selectedPeriod == key
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) TealAccent else CardBackground,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) TealAccent else BorderColor),
                        modifier = Modifier.clickable { selectedPeriod = key }
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isSelected) Color.White else TextColor,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            OutlinedButton(
                onClick = { generateCsv() },
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(32.dp).testTag("export_csv_button")
            ) {
                Icon(Icons.Default.Download, contentDescription = null, tint = TealAccent, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Exporter CSV", fontSize = 11.5.sp, color = TealAccent, fontWeight = FontWeight.Bold)
            }
        }

        // Dynamic Content
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (selectedType) {
                "sales" -> {
                    item {
                        val ca = filteredSales.sumOf { it.total }
                        val paid = filteredSales.sumOf { it.paid }
                        val remaining = filteredSales.sumOf { it.remaining }

                        ReportSummaryCard(
                            title = "Ventes totales",
                            mainValue = formatCurrency(ca),
                            sub1 = "Encaissé" to formatCurrency(paid),
                            sub2 = "Créances" to formatCurrency(remaining),
                            sub3 = "Transactions" to "${filteredSales.size}"
                        )
                    }

                    items(filteredSales) { s ->
                        ReportRowItem(
                            title = "${s.invoiceNo} · ${s.customerName}",
                            sub = "${s.date} · ${s.paymentMethod} · Vendeur ${s.seller}",
                            value = formatCurrency(s.total)
                        )
                    }
                }

                "stock" -> {
                    item {
                        val stockValue = products.sumOf { it.stock * it.purchasePrice }
                        val potentialCA = products.sumOf { it.stock * it.sellingPrice }
                        val totalUnits = products.sumOf { it.stock }

                        ReportSummaryCard(
                            title = "Valorisation du stock",
                            mainValue = formatCurrency(stockValue),
                            sub1 = "CA potentiel" to formatCurrency(potentialCA),
                            sub2 = "Unités" to "$totalUnits",
                            sub3 = "Références" to "${products.size}"
                        )
                    }

                    items(products) { p ->
                        ReportRowItem(
                            title = "${p.brand} ${p.name}",
                            sub = "${p.category} · Stock : ${p.stock} · Achat : ${formatCurrency(p.purchasePrice)}",
                            value = formatCurrency(p.stock * p.purchasePrice)
                        )
                    }
                }

                "top_products" -> {
                    val salesItemMap = saleItems.groupBy { it.productId }
                    val topList = products.map { p ->
                        val itemsSold = salesItemMap[p.id]?.sumOf { it.qty } ?: 0
                        val revenue = salesItemMap[p.id]?.sumOf { (it.qty * it.unitPrice) - it.discount } ?: 0L
                        Triple(p, itemsSold, revenue)
                    }.sortedByDescending { it.second }

                    item {
                        Text("Classement par unités vendues", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                    }

                    items(topList) { (p, qty, revenue) ->
                        ReportRowItem(
                            title = "${p.brand} ${p.name}",
                            sub = "$qty unité(s) vendue(s)",
                            value = formatCurrency(revenue)
                        )
                    }
                }

                "brands" -> {
                    val brandGroups = products.groupBy { it.brand }
                    item {
                        Text("Répartition par marque en catalogue", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                    }

                    items(brandGroups.toList()) { (brand, prods) ->
                        val brandStock = prods.sumOf { it.stock }
                        val brandVal = prods.sumOf { it.stock * it.purchasePrice }
                        ReportRowItem(
                            title = brand,
                            sub = "${prods.size} modèle(s) · $brandStock unités",
                            value = formatCurrency(brandVal)
                        )
                    }
                }

                "expenses" -> {
                    item {
                        val totalExp = filteredExpenses.sumOf { it.amount }
                        ReportSummaryCard(
                            title = "Dépenses totales",
                            mainValue = formatCurrency(totalExp),
                            sub1 = "Lignes" to "${filteredExpenses.size}",
                            sub2 = "Période" to selectedPeriod,
                            sub3 = "" to ""
                        )
                    }

                    items(filteredExpenses) { e ->
                        ReportRowItem(
                            title = "${e.category} — ${e.description.ifEmpty { "Sans libellé" }}",
                            sub = "${e.date} · ${e.user}",
                            value = formatCurrency(e.amount)
                        )
                    }
                }

                "debts_clients" -> {
                    val unpaidSales = sales.filter { it.remaining > 0 }
                    item {
                        val totalClientDebts = unpaidSales.sumOf { it.remaining }
                        ReportSummaryCard(
                            title = "Créances clients en cours",
                            mainValue = formatCurrency(totalClientDebts),
                            sub1 = "Factures" to "${unpaidSales.size}",
                            sub2 = "Clients" to "${unpaidSales.map { it.customerName }.distinct().size}",
                            sub3 = "" to ""
                        )
                    }

                    items(unpaidSales) { s ->
                        ReportRowItem(
                            title = "${s.customerName} (${s.invoiceNo})",
                            sub = "${s.date} · Total facture : ${formatCurrency(s.total)}",
                            value = formatCurrency(s.remaining)
                        )
                    }
                }

                "debts_suppliers" -> {
                    val unpaidPurchases = purchases.filter { it.remaining > 0 }
                    item {
                        val totalSupplierDebts = unpaidPurchases.sumOf { it.remaining }
                        ReportSummaryCard(
                            title = "Dettes fournisseurs en cours",
                            mainValue = formatCurrency(totalSupplierDebts),
                            sub1 = "Factures" to "${unpaidPurchases.size}",
                            sub2 = "Fournisseurs" to "${unpaidPurchases.map { it.supplierName }.distinct().size}",
                            sub3 = "" to ""
                        )
                    }

                    items(unpaidPurchases) { p ->
                        ReportRowItem(
                            title = "${p.supplierName} (${p.invoiceNo})",
                            sub = "${p.date} · Total achat : ${formatCurrency(p.total)}",
                            value = formatCurrency(p.remaining)
                        )
                    }
                }
            }
        }
    }

    if (showExportDialog) {
        BottomSheetContainer(
            title = "Exporter les données (CSV)",
            onClose = { showExportDialog = false },
            footer = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("ElectroSmart CSV", exportContent)
                        clipboard.setPrimaryClip(clip)
                        copiedToClipboard = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("copy_csv_button")
                ) {
                    Text(if (copiedToClipboard) "Copié dans le presse-papier ✓" else "Copier le CSV", fontWeight = FontWeight.Bold)
                }
            }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Ce fichier CSV peut être ouvert dans Excel ou Google Sheets.",
                    fontSize = 12.sp,
                    color = TextMuted,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = PaperBackground,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 220.dp)
                ) {
                    Text(
                        text = exportContent,
                        fontSize = 11.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ReportSummaryCard(
    title: String,
    mainValue: String,
    sub1: Pair<String, String>,
    sub2: Pair<String, String>,
    sub3: Pair<String, String>
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = CardBackground,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextMuted)
            Spacer(modifier = Modifier.height(4.dp))
            Text(mainValue, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = BorderColor.copy(alpha = 0.6f))
            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                if (sub1.first.isNotEmpty()) {
                    Column {
                        Text(sub1.first, fontSize = 11.sp, color = TextMuted)
                        Text(sub1.second, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextColor)
                    }
                }
                if (sub2.first.isNotEmpty()) {
                    Column {
                        Text(sub2.first, fontSize = 11.sp, color = TextMuted)
                        Text(sub2.second, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextColor)
                    }
                }
                if (sub3.first.isNotEmpty()) {
                    Column {
                        Text(sub3.first, fontSize = 11.sp, color = TextMuted)
                        Text(sub3.second, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextColor)
                    }
                }
            }
        }
    }
}

@Composable
fun ReportRowItem(
    title: String,
    sub: String,
    value: String
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = CardBackground,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextColor)
                Text(sub, fontSize = 11.sp, color = TextMuted)
            }
            Text(value, fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
        }
    }
}
