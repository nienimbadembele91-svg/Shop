package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppUserEntity
import com.example.ui.components.*
import com.example.ui.model.RolePermissions
import com.example.ui.theme.*

val ROLES = listOf("Administrateur", "Gérant", "Caissier", "Magasinier")

@Composable
fun MoreScreen(
    currentUser: AppUserEntity,
    users: List<AppUserEntity>,
    permissions: RolePermissions,
    onLogout: () -> Unit,
    onOpenModule: (String) -> Unit,
    onAddUser: (name: String, role: String, pin: String) -> Unit,
    onUpdateUser: (user: AppUserEntity) -> Unit,
    onToggleUserActive: (user: AppUserEntity) -> Unit,
    onWipeAllData: () -> Unit
) {
    var showUserDialog by remember { mutableStateOf(false) }
    var editingUser by remember { mutableStateOf<AppUserEntity?>(null) }
    var wipeCode by remember { mutableStateOf<String?>(null) }
    var wipeInput by remember { mutableStateOf("") }

    val activeAdmins = users.filter { it.role == "Administrateur" && it.active }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperBackground),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Connected profile card
        item {
            Text("Profil connecté", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = CardBackground,
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(currentUser.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextColor)
                    Text(currentUser.role, fontSize = 12.sp, color = GoldDark, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Accès : ${permissions.tabs.joinToString(" · ")}",
                        fontSize = 11.5.sp,
                        color = TextMuted
                    )
                }
            }
        }

        // Team & Access section (if canManageUsers)
        if (permissions.canManageUsers) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Équipe & accès", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                    Text(
                        text = "+ Ajouter",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TealAccent,
                        modifier = Modifier
                            .clickable {
                                editingUser = null
                                showUserDialog = true
                            }
                            .testTag("add_user_button")
                    )
                }
            }

            items(users) { u ->
                val isSelf = u.id == currentUser.id
                val canToggle = !(u.role == "Administrateur" && u.active && activeAdmins.size <= 1)

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CardBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .alpha(if (u.active) 1f else 0.55f)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${u.name}${if (isSelf) " (vous)" else ""}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextColor
                            )
                            Text(
                                text = "${u.role} · PIN ${u.pin}${if (!u.active) " · Inactif" else ""}",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = {
                                    editingUser = u
                                    showUserDialog = true
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("Modifier", fontSize = 11.sp)
                            }

                            OutlinedButton(
                                onClick = { if (canToggle) onToggleUserActive(u) },
                                enabled = canToggle,
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = if (u.active) RedAlert else TealAccent
                                ),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text(if (u.active) "Désactiver" else "Réactiver", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Additional Management Modules
        item {
            Text("Modules de gestion", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
        }

        item {
            val modules = listOf(
                Triple("suppliers", "Fournisseurs & achats", Icons.Default.LocalShipping),
                Triple("expenses", "Dépenses", Icons.Default.AccountBalanceWallet),
                Triple("reports", "Rapports", Icons.Default.BarChart),
                Triple("audit", "Journal d'activité", Icons.Default.Assignment)
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                modules.forEach { (key, label, icon) ->
                    val allowed = when (key) {
                        "suppliers" -> permissions.canManageSuppliers
                        "expenses" -> permissions.canManageExpenses
                        "reports" -> permissions.canViewReports
                        "audit" -> permissions.canViewAudit
                        else -> false
                    }

                    if (allowed) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = CardBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenModule(key) }
                                .testTag("more_module_$key")
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Icon(imageVector = icon, contentDescription = null, tint = TealAccent, modifier = Modifier.size(20.dp))
                                    Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextColor)
                                }
                                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted)
                            }
                        }
                    }
                }
            }
        }

        // Logout
        item {
            OutlinedButton(
                onClick = onLogout,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = RedAlert),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("logout_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Se déconnecter (${currentUser.name})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        // Sensitive Wipe Zone (Admin only)
        if (permissions.canDeleteData) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = RedSoft,
                    border = androidx.compose.foundation.BorderStroke(1.dp, RedAlert.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = RedAlert, modifier = Modifier.size(18.dp))
                            Text("Zone sensible", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = RedAlert)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Supprime définitivement tous les produits, stocks, ventes et clients de cette boutique. Action irréversible, réservée à l'administrateur.",
                            fontSize = 11.5.sp,
                            color = TextColor
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                wipeCode = "${(100000..999999).random()}"
                                wipeInput = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RedAlert),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("start_wipe_button")
                        ) {
                            Text("Supprimer toutes les données", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                        }
                    }
                }
            }
        }
    }

    // User Add/Edit Dialog
    if (showUserDialog) {
        UserFormDialog(
            initial = editingUser,
            onClose = {
                showUserDialog = false
                editingUser = null
            },
            onSave = { name, role, pin ->
                if (editingUser != null) {
                    onUpdateUser(editingUser!!.copy(name = name, role = role, pin = pin))
                } else {
                    onAddUser(name, role, pin)
                }
                showUserDialog = false
                editingUser = null
            }
        )
    }

    // Wipe Confirmation Sheet
    if (wipeCode != null) {
        BottomSheetContainer(
            title = "Confirmer la suppression",
            onClose = { wipeCode = null },
            footer = {
                val isMatch = wipeInput == wipeCode
                Button(
                    onClick = {
                        if (isMatch) {
                            onWipeAllData()
                            wipeCode = null
                        }
                    },
                    enabled = isMatch,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RedAlert,
                        disabledContainerColor = Color(0xFFD8D3C6)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("confirm_wipe_button")
                ) {
                    Text("Effacer définitivement toutes les données", fontWeight = FontWeight.Bold)
                }
            }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Pour confirmer la suppression complète, entrez le code suivant :",
                    fontSize = 12.5.sp,
                    color = TextColor,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = PaperBackground,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
                ) {
                    Text(
                        text = wipeCode ?: "",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkPrimary,
                        letterSpacing = 4.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                    )
                }

                FormField(label = "Saisir le code ci-dessus") {
                    StyledTextInput(
                        value = wipeInput,
                        onValueChange = { wipeInput = it },
                        placeholder = "000000",
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.testTag("wipe_code_input")
                    )
                }
            }
        }
    }
}

@Composable
fun UserFormDialog(
    initial: AppUserEntity?,
    onClose: () -> Unit,
    onSave: (name: String, role: String, pin: String) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var role by remember { mutableStateOf(initial?.role ?: "Caissier") }
    var pin by remember { mutableStateOf(initial?.pin ?: "") }

    val isValid = name.isNotBlank() && pin.length == 4 && pin.all { it.isDigit() }

    BottomSheetContainer(
        title = if (initial != null) "Modifier l'utilisateur" else "Ajouter un utilisateur",
        onClose = onClose,
        footer = {
            Button(
                onClick = { if (isValid) onSave(name, role, pin) },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_user_button")
            ) {
                Text(
                    text = if (initial != null) "Enregistrer les modifications" else "Ajouter l'utilisateur",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            FormField(label = "Nom complet *") {
                StyledTextInput(value = name, onValueChange = { name = it }, placeholder = "ex : Oumou Traoré")
            }

            FormField(label = "Poste / Rôle") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ROLES.forEach { r ->
                        val isSelected = role == r
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = if (isSelected) InkPrimary else CardBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                            modifier = Modifier.clickable { role = r }
                        ) {
                            Text(
                                text = r,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.White else TextColor,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            FormField(label = "Code PIN (4 chiffres) *") {
                StyledTextInput(
                    value = pin,
                    onValueChange = { if (it.length <= 4 && it.all { ch -> ch.isDigit() }) pin = it },
                    placeholder = "1234",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.testTag("user_pin_input")
                )
            }
        }
    }
}
