package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppUserEntity
import com.example.ui.theme.*

@Composable
fun LoginScreen(
    users: List<AppUserEntity>,
    onLogin: (AppUserEntity) -> Unit
) {
    val activeUsers = users.filter { it.active }
    var selectedUser by remember(activeUsers) { mutableStateOf(activeUsers.firstOrNull() ?: users.firstOrNull()) }
    var pin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    fun onDigit(d: String) {
        errorMessage = ""
        if (d == "back") {
            if (pin.isNotEmpty()) pin = pin.dropLast(1)
            return
        }
        if (pin.length >= 4) return
        val next = pin + d
        pin = next
        if (next.length == 4) {
            val user = selectedUser
            if (user != null && next == user.pin) {
                onLogin(user)
            } else {
                errorMessage = "Code PIN incorrect"
                pin = ""
            }
        }
    }

    Surface(
        color = InkPrimary,
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Logo & Title
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(GoldAccent),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ShoppingCart,
                    contentDescription = null,
                    tint = InkPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "ELECTRO_SMART",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 1.sp
            )
            Text(
                text = "Gestion boutique téléphonie · Mali",
                fontSize = 12.5.sp,
                color = Color(0xFFB9C4D6)
            )

            Spacer(modifier = Modifier.height(26.dp))

            // User Profile selector
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Choisir un profil",
                    fontSize = 12.sp,
                    color = Color(0xFFB9C4D6),
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    activeUsers.forEach { u ->
                        val isSelected = selectedUser?.id == u.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) GoldAccent.copy(alpha = 0.15f) else Color.Transparent,
                            border = androidx.compose.foundation.BorderStroke(
                                1.5.dp,
                                if (isSelected) GoldAccent else Color.White.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier
                                .clickable {
                                    selectedUser = u
                                    pin = ""
                                    errorMessage = ""
                                }
                                .testTag("login_user_${u.id}")
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                                Text(
                                    text = u.name,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                                Text(
                                    text = u.role,
                                    fontSize = 10.5.sp,
                                    color = GoldAccent
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // PIN Dots
            Row(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 4) {
                    val isFilled = pin.length > i
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .clip(CircleShape)
                            .background(if (isFilled) GoldAccent else Color.Transparent)
                            .border(1.5.dp, GoldAccent, CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            AnimatedVisibility(visible = errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = RedAlert,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Text(
                text = "Code de démonstration : ${selectedUser?.pin ?: "1111"}",
                color = Color(0xFF8695AB),
                fontSize = 11.5.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
            )

            // Keypad
            val buttons = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("bio", "0", "back")
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .widthIn(max = 280.dp)
                    .fillMaxWidth()
            ) {
                buttons.forEach { row ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        row.forEach { key ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.05f))
                                    .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape)
                                    .clickable {
                                        if (key != "bio") onDigit(key)
                                    }
                                    .testTag("keypad_$key"),
                                contentAlignment = Alignment.Center
                            ) {
                                when (key) {
                                    "back" -> Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Backspace,
                                        contentDescription = "Effacer",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    "bio" -> Icon(
                                        imageVector = Icons.Default.Fingerprint,
                                        contentDescription = "Biométrie",
                                        tint = GoldAccent,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    else -> Text(
                                        text = key,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
