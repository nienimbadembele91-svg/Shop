package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val InkPrimary = Color(0xFF10233F)
val InkSecondary = Color(0xFF16324F)
val PaperBackground = Color(0xFFFBF8F2)
val CardBackground = Color(0xFFFFFFFF)
val GoldAccent = Color(0xFFD9A441)
val GoldDark = Color(0xFFB8842A)
val TealAccent = Color(0xFF146B54)
val TealSoft = Color(0xFFE4F1EC)
val RedAlert = Color(0xFFC1443C)
val RedSoft = Color(0xFFFBE8E6)
val AmberAccent = Color(0xFFB8842A)
val AmberSoft = Color(0xFFFBF0DC)
val TextColor = Color(0xFF16202B)
val TextMuted = Color(0xFF6C7480)
val BorderColor = Color(0xFFE7E2D6)

