package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.Pill
import com.example.ui.components.PillTone
import com.example.ui.components.formatCurrency
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(
    products: List<ProductEntity>,
    sales: List<SaleEntity>,
    saleItems: List<SaleItemEntity>,
    expenses: List<ExpenseEntity>,
    purchases: List<PurchaseEntity>,
    onNavigateToSales: () -> Unit,
    onNavigateToStock: () -> Unit
) {
    var selectedPeriod by remember { mutableStateOf("today") }

    val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    val weekAgoStr = remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -6)
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
    }
    val currentMonthStr = remember { todayStr.take(7) }

    val activeSales = remember(sales, selectedPeriod) {
        when (selectedPeriod) {
            "today" -> sales.filter { it.date == todayStr }
            "week" -> sales.filter { it.date >= weekAgoStr }
            "month" -> sales.filter { it.date.startsWith(currentMonthStr) }
            else -> sales
        }
    }

    val totalCA = activeSales.sumOf { it.total }

    // Estimate profit
    val totalProfit = remember(activeSales, saleItems, products) {
        var profit = 0L
        val productMap = products.associateBy { it.id }
        activeSales.forEach { sale ->
            val itemsForSale = saleItems.filter { it.saleId == sale.id }
            itemsForSale.forEach { item ->
                val p = productMap[item.productId]
                if (p != null) {
                    val unitMargin = item.unitPrice - p.purchasePrice
                    profit += unitMargin * item.qty - item.discount
                }
            }
        }
        profit
    }

    val totalItemsSold = remember(activeSales, saleItems) {
        activeSales.sumOf { sale ->
            saleItems.filter { it.saleId == sale.id }.sumOf { it.qty }
        }
    }

    val stockValue = products.sumOf { it.stock * it.purchasePrice }
    val clientDebts = sales.sumOf { it.remaining }
    val supplierDebts = purchases.sumOf { it.remaining }
    val todayExpenses = expenses.filter { it.date == todayStr }.sumOf { it.amount }
    val todayCashSales = sales.filter { it.date == todayStr && it.paymentMethod == "Espèces" }.sumOf { it.paid }
    val outOfStockCount = products.count { it.stock == 0 }
    val lowStockCount = products.count { it.stock in 1..it.minStock }
    val lowStockProducts = products.filter { it.stock <= it.minStock }.take(5)

    // 7 days chart data
    val chartData = remember(sales) {
        (6 downTo 0).map { i ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -i)
            val dStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
            val label = SimpleDateFormat("EEE", Locale.FRENCH).format(cal.time).take(3)
            val dayTotal = sales.filter { it.date == dStr }.sumOf { it.total }
            Pair(label, dayTotal)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperBackground),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Period tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val periods = listOf("today" to "Aujourd'hui", "week" to "7 derniers jours", "month" to "Ce mois")
                periods.forEach { (key, label) ->
                    val isSelected = selectedPeriod == key
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = if (isSelected) TealAccent else CardBackground,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) TealAccent else BorderColor),
                        modifier = Modifier
                            .clickable { selectedPeriod = key }
                            .testTag("dashboard_period_$key")
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.White else TextMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Hero Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    val periodLabel = when (selectedPeriod) {
                        "today" -> "Aujourd'hui"
                        "week" -> "7 derniers jours"
                        else -> "Ce mois"
                    }
                    Text(
                        text = "Chiffre d'affaires · $periodLabel",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = formatCurrency(totalCA),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = BorderColor.copy(alpha = 0.6f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Bénéfice estimé", fontSize = 11.sp, color = TextMuted)
                            Text(
                                formatCurrency(totalProfit),
                                fontSize = 15.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TealAccent
                            )
                        }
                        Column {
                            Text("Articles vendus", fontSize = 11.sp, color = TextMuted)
                            Text(
                                "$totalItemsSold",
                                fontSize = 15.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = InkPrimary
                            )
                        }
                        Column {
                            Text("Ventes", fontSize = 11.sp, color = TextMuted)
                            Text(
                                "${activeSales.size}",
                                fontSize = 15.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = InkPrimary
                            )
                        }
                    }
                }
            }
        }

        // 7 Days Chart
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 14.dp)
            ) {
                Text(
                    text = "Ventes des 7 derniers jours",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = InkPrimary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBackground),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        val maxVal = chartData.maxOfOrNull { it.second }?.coerceAtLeast(10000L) ?: 10000L

                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                        ) {
                            val barWidth = 26.dp.toPx()
                            val spacing = (size.width - (chartData.size * barWidth)) / (chartData.size + 1)
                            val canvasHeight = size.height - 24.dp.toPx()

                            // Grid baseline
                            drawLine(
                                color = Color(0xFFEFEAE0),
                                start = Offset(0f, canvasHeight),
                                end = Offset(size.width, canvasHeight),
                                strokeWidth = 1.dp.toPx()
                            )

                            chartData.forEachIndexed { idx, (day, value) ->
                                val x = spacing + idx * (barWidth + spacing)
                                val barHeight = if (maxVal > 0) ((value.toFloat() / maxVal.toFloat()) * canvasHeight).coerceAtLeast(4.dp.toPx()) else 4.dp.toPx()
                                val y = canvasHeight - barHeight

                                drawRoundRect(
                                    color = TealAccent,
                                    topLeft = Offset(x, y),
                                    size = Size(barWidth, barHeight),
                                    cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                                )

                                drawContext.canvas.nativeCanvas.drawText(
                                    day,
                                    x + barWidth / 2f,
                                    size.height - 4.dp.toPx(),
                                    android.graphics.Paint().apply {
                                        color = android.graphics.Color.parseColor("#6C7480")
                                        textSize = 10.dp.toPx()
                                        textAlign = android.graphics.Paint.Align.CENTER
                                        isAntiAlias = true
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Horizontal Stats Strip
        item {
            val stats = listOf(
                Pair("Valeur du stock", formatCurrency(stockValue)),
                Pair("Créances clients", formatCurrency(clientDebts)),
                Pair("Dettes fournisseurs", formatCurrency(supplierDebts)),
                Pair("Dépenses du jour", formatCurrency(todayExpenses)),
                Pair("Caisse espèces (jour)", formatCurrency(todayCashSales)),
                Pair("Produits en rupture", "$outOfStockCount réf."),
                Pair("Stock sous le seuil", "$lowStockCount réf.")
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                stats.forEach { (label, value) ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = CardBackground,
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                        modifier = Modifier.width(148.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(label, fontSize = 11.sp, color = TextMuted, maxLines = 1)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                value,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = InkPrimary,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // Stock alerts
        if (lowStockProducts.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Alertes de stock",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkPrimary
                    )
                    Text(
                        text = "Voir tout",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TealAccent,
                        modifier = Modifier
                            .clickable { onNavigateToStock() }
                            .testTag("dashboard_see_all_stock")
                    )
                }
            }

            items(lowStockProducts) { p ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CardBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (p.stock == 0) RedAlert else GoldDark,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${p.brand} ${p.name}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextColor
                            )
                            Text(
                                text = "Stock : ${p.stock} · Seuil min : ${p.minStock}",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                        Pill(
                            text = if (p.stock == 0) "Rupture" else "Faible",
                            tone = if (p.stock == 0) PillTone.RED else PillTone.AMBER
                        )
                    }
                }
            }
        }

        // CTA: Nouvelle vente button
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Button(
                    onClick = onNavigateToSales,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = InkPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("dashboard_new_sale_cta")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "NOUVELLE VENTE",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}
