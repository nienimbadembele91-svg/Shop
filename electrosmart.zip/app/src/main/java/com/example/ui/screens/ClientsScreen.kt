package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CustomerEntity
import com.example.data.model.SaleEntity
import com.example.ui.components.*
import com.example.ui.model.RolePermissions
import com.example.ui.theme.*

@Composable
fun ClientsScreen(
    customers: List<CustomerEntity>,
    sales: List<SaleEntity>,
    permissions: RolePermissions,
    onAddCustomer: (name: String, phone: String, address: String, notes: String) -> Unit,
    onUpdateCustomer: (customer: CustomerEntity) -> Unit,
    onRecordPayment: (saleId: String, amount: Long, method: String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var editingCustomer by remember { mutableStateOf<CustomerEntity?>(null) }

    val filteredCustomers = remember(customers, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) customers
        else customers.filter {
            it.name.lowercase().contains(q) || it.phone.contains(q)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PaperBackground)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Search field
            Box(modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                ElectroSearchField(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    placeholder = "Nom ou téléphone du client..."
                )
            }

            if (filteredCustomers.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("Aucun client trouvé.", fontSize = 13.5.sp, color = TextMuted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredCustomers, key = { it.id }) { customer ->
                        val clientSales = sales.filter { it.customerId == customer.id }
                        val totalSpent = clientSales.sumOf { it.paid }
                        val totalCredit = clientSales.sumOf { it.remaining }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = CardBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedCustomer = customer }
                                .testTag("client_card_${customer.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(customer.name, fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = TextColor)
                                    Text(
                                        text = "${customer.phone.ifEmpty { "Sans téléphone" }} · Total dépensé : ${formatCurrency(totalSpent)}",
                                        fontSize = 11.5.sp,
                                        color = TextMuted
                                    )
                                }
                                if (totalCredit > 0) {
                                    Pill(text = "Doit ${formatCurrency(totalCredit)}", tone = PillTone.AMBER)
                                } else {
                                    Pill(text = "À jour", tone = PillTone.TEAL)
                                }
                            }
                        }
                    }
                }
            }
        }

        // FAB add client
        if (permissions.canManageClients) {
            FloatingActionButton(
                onClick = {
                    editingCustomer = null
                    showForm = true
                },
                containerColor = TealAccent,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 20.dp, bottom = 80.dp)
                    .testTag("add_client_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter un client")
            }
        }
    }

    // Detail Sheet
    if (selectedCustomer != null) {
        val c = selectedCustomer!!
        val clientSales = sales.filter { it.customerId == c.id }

        ClientDetailSheet(
            customer = c,
            sales = clientSales,
            canEdit = permissions.canManageClients,
            onClose = { selectedCustomer = null },
            onEdit = {
                editingCustomer = c
                selectedCustomer = null
                showForm = true
            },
            onRecordPayment = onRecordPayment
        )
    }

    // Form Dialog
    if (showForm) {
        ClientFormSheet(
            initial = editingCustomer,
            onClose = {
                showForm = false
                editingCustomer = null
            },
            onSave = { name, phone, address, notes ->
                if (editingCustomer != null) {
                    onUpdateCustomer(editingCustomer!!.copy(name = name, phone = phone, address = address, notes = notes))
                } else {
                    onAddCustomer(name, phone, address, notes)
                }
                showForm = false
                editingCustomer = null
            }
        )
    }
}

@Composable
fun ClientDetailSheet(
    customer: CustomerEntity,
    sales: List<SaleEntity>,
    canEdit: Boolean,
    onClose: () -> Unit,
    onEdit: () -> Unit,
    onRecordPayment: (saleId: String, amount: Long, method: String) -> Unit
) {
    val totalSpent = sales.sumOf { it.paid }
    val credit = sales.sumOf { it.remaining }
    val lastDate = sales.maxOfOrNull { it.date } ?: "—"

    var payingSale by remember { mutableStateOf<SaleEntity?>(null) }

    BottomSheetContainer(
        title = customer.name,
        onClose = onClose
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                if (credit > 0) {
                    Pill("Créance : ${formatCurrency(credit)}", tone = PillTone.AMBER)
                } else {
                    Pill("Aucune créance", tone = PillTone.TEAL)
                }
                Pill("${sales.size} achat(s)", tone = PillTone.MUTED)
            }

            // Grid info
            val items = listOf(
                "Téléphone" to customer.phone.ifEmpty { "—" },
                "Adresse" to customer.address.ifEmpty { "—" },
                "Total dépensé" to formatCurrency(totalSpent),
                "Dernier achat" to lastDate
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                items.chunked(2).forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        row.forEach { (label, value) ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = PaperBackground,
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(label, fontSize = 10.5.sp, color = TextMuted)
                                    Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextColor)
                                }
                            }
                        }
                    }
                }
            }

            if (customer.notes.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = PaperBackground,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
                ) {
                    Text(
                        text = customer.notes,
                        fontSize = 12.sp,
                        color = TextMuted,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Text("Historique d'achats", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = InkPrimary, modifier = Modifier.padding(bottom = 8.dp))

            if (sales.isEmpty()) {
                Text("Aucun achat enregistré pour ce client.", fontSize = 12.sp, color = TextMuted, modifier = Modifier.padding(bottom = 12.dp))
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 16.dp)) {
                    sales.reversed().forEach { s ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = PaperBackground,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${s.invoiceNo} · ${s.date}", fontSize = 12.sp, color = TextColor)
                                    Text(formatCurrency(s.total), fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                                }

                                if (s.remaining > 0) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "Reste : ${formatCurrency(s.remaining)}",
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = RedAlert
                                        )

                                        Button(
                                            onClick = { payingSale = s },
                                            colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                                            shape = RoundedCornerShape(999.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                            modifier = Modifier.height(28.dp).testTag("pay_credit_${s.id}")
                                        ) {
                                            Text("Enregistrer un paiement", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                } else {
                                    Text("Soldée", fontSize = 11.sp, color = TealAccent, modifier = Modifier.padding(top = 4.dp))
                                }
                            }
                        }
                    }
                }
            }

            if (canEdit) {
                OutlinedButton(
                    onClick = onEdit,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                ) {
                    Text("Modifier ce client", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextColor)
                }
            }
        }
    }

    if (payingSale != null) {
        PayCreditDialog(
            sale = payingSale!!,
            onClose = { payingSale = null },
            onSave = { amt, method ->
                onRecordPayment(payingSale!!.id, amt, method)
                payingSale = null
            }
        )
    }
}

@Composable
fun PayCreditDialog(
    sale: SaleEntity,
    onClose: () -> Unit,
    onSave: (amount: Long, method: String) -> Unit
) {
    var amountStr by remember { mutableStateOf("${sale.remaining}") }
    var selectedMethod by remember { mutableStateOf("Espèces") }

    val amount = amountStr.toLongOrNull() ?: 0L
    val isValid = amount in 1..sale.remaining

    BottomSheetContainer(
        title = "Paiement · Facture ${sale.invoiceNo}",
        onClose = onClose,
        footer = {
            Button(
                onClick = { if (isValid) onSave(amount, selectedMethod) },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text("Enregistrer le paiement", fontWeight = FontWeight.Bold)
            }
        }
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Reste à payer : ${formatCurrency(sale.remaining)}",
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                color = RedAlert,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            FormField(label = "Montant payé (F CFA)") {
                StyledTextInput(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }

            FormField(label = "Mode de paiement") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PAYMENT_METHODS.forEach { m ->
                        val isSelected = selectedMethod == m
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = if (isSelected) InkPrimary else CardBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) InkPrimary else BorderColor),
                            modifier = Modifier.clickable { selectedMethod = m }
                        ) {
                            Text(
                                text = m,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.White else TextColor,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ClientFormSheet(
    initial: CustomerEntity?,
    onClose: () -> Unit,
    onSave: (name: String, phone: String, address: String, notes: String) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var address by remember { mutableStateOf(initial?.address ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }

    val isValid = name.isNotBlank()

    BottomSheetContainer(
        title = if (initial != null) "Modifier le client" else "Nouveau client",
        onClose = onClose,
        footer = {
            Button(
                onClick = { if (isValid) onSave(name, phone, address, notes) },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text(
                    text = if (initial != null) "Enregistrer les modifications" else "Ajouter le client",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            FormField(label = "Nom complet *") {
                StyledTextInput(value = name, onValueChange = { name = it }, placeholder = "ex : Aminata Coulibaly")
            }
            FormField(label = "Téléphone") {
                StyledTextInput(value = phone, onValueChange = { phone = it }, placeholder = "+223 XX XX XX XX")
            }
            FormField(label = "Adresse") {
                StyledTextInput(value = address, onValueChange = { address = it }, placeholder = "Quartier, ville")
            }
            FormField(label = "Notes") {
                StyledTextInput(value = notes, onValueChange = { notes = it }, placeholder = "Client fidèle, préférences...")
            }
        }
    }
}
