package com.example.ui.model

data class RolePermissions(
    val tabs: List<String>,
    val canManageProducts: Boolean,
    val canAdjustStock: Boolean,
    val canDoInventory: Boolean,
    val canManageClients: Boolean,
    val canDeleteData: Boolean,
    val canEditPrices: Boolean,
    val canManageUsers: Boolean,
    val canManageSuppliers: Boolean,
    val canManageExpenses: Boolean,
    val canViewReports: Boolean,
    val canViewAudit: Boolean
)

object PermissionsManager {
    val ADMIN = RolePermissions(
        tabs = listOf("dashboard", "sales", "stock", "products", "clients", "more"),
        canManageProducts = true,
        canAdjustStock = true,
        canDoInventory = true,
        canManageClients = true,
        canDeleteData = true,
        canEditPrices = true,
        canManageUsers = true,
        canManageSuppliers = true,
        canManageExpenses = true,
        canViewReports = true,
        canViewAudit = true
    )

    val GERANT = RolePermissions(
        tabs = listOf("dashboard", "sales", "stock", "products", "clients", "more"),
        canManageProducts = true,
        canAdjustStock = true,
        canDoInventory = true,
        canManageClients = true,
        canDeleteData = false,
        canEditPrices = true,
        canManageUsers = false,
        canManageSuppliers = true,
        canManageExpenses = true,
        canViewReports = true,
        canViewAudit = true
    )

    val CAISSIER = RolePermissions(
        tabs = listOf("dashboard", "sales", "clients", "more"),
        canManageProducts = false,
        canAdjustStock = false,
        canDoInventory = false,
        canManageClients = true,
        canDeleteData = false,
        canEditPrices = false,
        canManageUsers = false,
        canManageSuppliers = false,
        canManageExpenses = true,
        canViewReports = false,
        canViewAudit = false
    )

    val MAGASINIER = RolePermissions(
        tabs = listOf("dashboard", "stock", "products", "more"),
        canManageProducts = true,
        canAdjustStock = true,
        canDoInventory = true,
        canManageClients = false,
        canDeleteData = false,
        canEditPrices = false,
        canManageUsers = false,
        canManageSuppliers = true,
        canManageExpenses = false,
        canViewReports = false,
        canViewAudit = false
    )

    fun forRole(role: String): RolePermissions {
        return when (role) {
            "Administrateur" -> ADMIN
            "Gérant" -> GERANT
            "Caissier" -> CAISSIER
            "Magasinier" -> MAGASINIER
            else -> CAISSIER
        }
    }
}
